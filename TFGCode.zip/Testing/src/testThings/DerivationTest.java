package testThings;

import java.util.ArrayList;
import java.util.HashMap;

import javafx.util.Pair;
import mealyMachine.MealyMachine;

public class DerivationTest {
	private ArrayList<Integer> stateList;
	private ArrayList<Integer> inpStates;
	private ArrayList<Integer> outStates;
	private ArrayList<Integer> passStates;
	private ArrayList<Integer> failStates;
	private ArrayList<String> inAlph;
	private ArrayList<String> outAlph;
	private Integer initialState=0;
	private HashMap<Integer,Pair<String,Integer>> transitionFunction;
	ArrayList<Pair<Integer,Integer>> saux;
	
	public DerivationTest(MealyMachine m) {
		stateList=new ArrayList<Integer>();
		inpStates=new ArrayList<Integer>();
		outStates=new ArrayList<Integer>();
		passStates=new ArrayList<Integer>();
		failStates=new ArrayList<Integer>();
		ArrayList<String> inAlph=(ArrayList<String>) m.getInAlph().clone();
		ArrayList<String> outAlph=(ArrayList<String>) m.getOutAlph().clone();
		saux=new ArrayList<Pair<Integer,Integer>>();
		stateList.add(0);
		saux.add(new Pair<Integer,Integer>(0,0));
		transitionFunction=new HashMap<Integer,Pair<String,Integer>>();
	}

	private void option1() {
		Pair<Integer,Integer> p=saux.get(0);
		saux.remove(0);
		passStates.add(p.getValue());
	}

	private void option2(MealyMachine m) {
		Pair<Integer,Integer> p=saux.get(0);
		saux=new ArrayList<Pair<Integer, Integer>>();
		ArrayList<String> inps=m.getInputsFromState(p.getKey());
		if(inps.size()!=0) {
			Integer nuevo=stateList.size();
			stateList.add(nuevo);
			inpStates.add(p.getValue());
			outStates.add(nuevo);
			String inp=inps.get(0);
			transitionFunction.put(p.getValue(), new Pair<String,Integer>(inp,nuevo));
			ArrayList<String> outs=m.getOutputsFromStateInput(p.getKey(), inp);
			Integer nuevo2=stateList.size();
			stateList.add(nuevo2);
			failStates.add(nuevo2);
			Integer nuevo3=0;
			for(int j=0;j<this.outAlph.size();j++) {
				if(!outs.contains(outAlph.get(j))){
					transitionFunction.put(nuevo, 
							new Pair<String,Integer>(outAlph.get(j),nuevo2));
				}else {
					nuevo3=stateList.size();
					stateList.add(nuevo3);
					transitionFunction.put(nuevo, 
							new Pair<String,Integer>(outAlph.get(j),nuevo3));
				}
			}
			if(outs.size()>1) {
				saux.add(new Pair<Integer,Integer>(
						m.after(p.getKey(), inp, outs.get(outs.size()-1)),nuevo3));
			}
		}
	}
	
	private class derivationState{
		public Integer dest;
		public Integer orig;
		public String t;
		public Integer getDest() {
			return dest;
		}
		public void setDest(Integer dest) {
			this.dest = dest;
		}
		public Integer getOrig() {
			return orig;
		}
		public void setOrig(Integer orig) {
			this.orig = orig;
		}
		public String getT() {
			return t;
		}
		public void setT(String t) {
			this.t = t;
		}
		public derivationState(Integer a, Integer b, String c) {
			orig=a;
			dest=b;
			t=c;
		}
	}
	
}
