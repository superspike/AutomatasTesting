package testThings;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;

import mealyMachine.MealyMachine;

public class NonDeterministicTestComparer {
	private MealyMachine m;
	private int mutType;
	private ArrayList<Integer> bestTests;
	private int numMuts;
	//private ArrayList<TestTester> ttList;
	private ArrayList<MealyMachine> mutList;
	private ArrayList<NonDeterministicTest> testList;
	private ArrayList<ArrayList<Integer>> compMatrix;
	private ArrayList<floatInt> percs;
	private ArrayList<floatInt> resiliences;
	private ArrayList<floatInt> resiliencesSorted;
	private ArrayList<floatInt> percsSorted;
	public NonDeterministicTestComparer
		(MealyMachine m, int mutType, int numMuts, double prob){
		this.m=m;
		this.mutType=mutType;
		this.numMuts=numMuts;
		//ttList=new ArrayList<TestTester>();
		mutList = new ArrayList<MealyMachine>();
		testList = new ArrayList<NonDeterministicTest>();
		compMatrix = new ArrayList<ArrayList<Integer>>();
		createMutations(prob);
	}
	public NonDeterministicTestComparer(MealyMachine mm, Integer value) {
		this.m=mm;
		this.mutType=value;
		//ttList=new ArrayList<TestTester>();
		mutList = mm.generateAllMutants(value);
		this.numMuts=mutList.size();
		testList = new ArrayList<NonDeterministicTest>();
		compMatrix = new ArrayList<ArrayList<Integer>>();
	}
	public void createMutations(double prob) {
		for(int i = 0; i < this.numMuts; i++) {
			this.mutList.add(m.generateMutant(this.mutType, prob));
		}
	}

	public void addTest(NonDeterministicTest t) {
		this.testList.add(t);
	}
	
	public void runAll(){
		float porc;
		percs=new ArrayList<floatInt>();
		percsSorted=new ArrayList<floatInt>();
		resiliences=new ArrayList<floatInt>();
		for(int i = 0; i < testList.size(); i++) {
			ArrayList<Integer> tempComps = new ArrayList<Integer>();
			//testList.get(i).runTest();
			for(int j = 0; j < mutList.size(); j++) {
				tempComps.add(compare(testList.get(i), mutList.get(j)));
			}
			int cont=0;
			for(int j = 0; j <  tempComps.size(); j++) {
				if(tempComps.get(j)>0)cont++;
			}
			porc=((float)cont)/tempComps.size();
			percs.add(new floatInt(
					(float)Math.round(porc*10000)/100,
					i)
				);
			//Al salir del bucle tempComps es un arrayList con los valores de las comparaciones de testList(i)
			//runneado en la m�quina original vs en cada mutaci�n
			
			//Ahora a�adimos tempComps a compMatrix y pasamos al siguiente test
			compMatrix.add(tempComps);
		}
		
		int cont;
		for(int i=0;i<this.compMatrix.get(0).size();i++) {
			cont=0;
			for(int j=0;j<this.compMatrix.size();j++) {
				if(compMatrix.get(j).get(i)==0)cont++;
			}
			porc=((float)cont)/compMatrix.size();
			resiliences.add(new floatInt(
					(float)Math.round(porc*10000)/100,
					i)
				);
		}
		resiliencesSorted=(ArrayList<floatInt>) resiliences.clone();
		resiliencesSorted.sort((floatInt s1, floatInt s2)->{
			if(s1.f>s2.f)return -1;
			if(s1.f==s2.f)return 0;
			return 1;
			}
		);

		percsSorted=(ArrayList<floatInt>) percs.clone();
		percsSorted.sort((floatInt s1, floatInt s2)->{
			if(s1.f>s2.f)return -1;
			if(s1.f==s2.f)return 0;
			return 1;
			}
		);
	}

	public String topInputs(int num){
		StringBuilder sb=new StringBuilder();
		if(num>percsSorted.size())num=percsSorted.size();
		ArrayList<floatInt> aux=new ArrayList<floatInt>(percsSorted.subList(0,num));
		ArrayList<String> caso;
		for(int i=0;i<aux.size();i++) {
			caso=this.testList.get(aux.get(i).i).getInputs();
			for(int j=0;j<caso.size();j++) {
				sb.append(caso.get(j));
				sb.append(" ");
			}
			sb.append("\n");
		}
		return sb.toString();
	}
	
	public String topMutants(int num){
		StringBuilder sb=new StringBuilder();
		if(num>resiliencesSorted.size())num=resiliencesSorted.size();
		ArrayList<floatInt>aux=new ArrayList<floatInt>(resiliencesSorted.subList(0,num));
		if(this.mutType<2) {
			for(int i=0;i<aux.size();i++) {
				sb.append(mutList.get(aux.get(i).i).getMutCode());
				sb.append("\n");
			}
		}
		else {

			for(int i=0;i<aux.size();i++) {
				sb.append(mutList.get(aux.get(i).i).toString());
				sb.append("\n###\n");
			}
		}
		return sb.toString();
	}
	
	public Integer compare(NonDeterministicTest t, MealyMachine mutation){
		ArrayList<ArrayList<String>> outs = t.getOutputs();
		ArrayList<ArrayList<String>> outs2 = mutation.generateOutputs(t.getInputs());
		for(int i=0;i<outs2.size();i++) {
			if(!outs.contains(outs2.get(i)))return 1;
		}
		return 0;
	}
	
	
	
	public String getMatrix() {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < this.compMatrix.size(); i++) {
			sb.append(getRow(this.compMatrix.get(i)));
		}
		return sb.toString();
	}

	public String getPerc() {
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<percs.size();i++) {
			sb.append(percs.get(i).f);
			sb.append("%\n");
		}
		return sb.toString();
	}
	
	public String mutScore() {
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<resiliencesSorted.size();i++) {
			sb.append(resiliencesSorted.get(i).f);
			sb.append("%\n");
		}
		return sb.toString();
	}
	
	public float getPerc(int pos) {
		return percs.get(pos).f;
	}
	
	public void showMatrix() {
		for(int i = 0; i < this.compMatrix.size(); i++) {
			//System.out.println(this.compMatrix.get(i).size());
			showRow(this.compMatrix.get(i));
		}
	}
	
	public String getRow(ArrayList<Integer> list){
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < list.size(); i++) {
			sb.append(list.get(i).toString());
			sb.append(" ");
		}
		sb.append("\n");
		return sb.toString();
	}
	
	//Cada fila son los datos de las comparaciones de un test con todas las mutaciones
	public void showRow(ArrayList<Integer> list) {
		for(int i = 0; i < list.size(); i++) {
			System.out.print(list.get(i));
			System.out.print(' ');
		}
		System.out.print('\n');
	}
	
	public int getNumStates(){
		return this.m.getNumStates();
	}
	public int getAlphSize(){
		return this.m.getOutAlphSize();
	}
	public MealyMachine getMealy(){
		return this.m;
	}
	public int size(){
		return this.testList.size();
	}
	
	private class floatInt{

		public float f;
		public int i;
		public floatInt(){
			f=i=0;
		}
		
		public floatInt(float f, int i){
			this.f=f;
			this.i=i;
		}
				
	}
	
	public void addMutants(ArrayList<MealyMachine> list) {
		this.mutList.addAll(list);
	}
	
}
