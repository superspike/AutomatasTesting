package view;

import javafx.scene.Scene;
import javafx.scene.control.Dialog;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ErrorDialog extends Stage{
	private String info;
	public ErrorDialog(String inf, Stage st) {
		super();
		info=inf;
		this.initModality(Modality.APPLICATION_MODAL);
		this.initOwner(st);
		Text t=new Text("Error:\n "+inf);
		HBox dialogHBox=new HBox(20);
		dialogHBox.getChildren().add(t);
		Scene dialogScene = new Scene(dialogHBox, 300, 200);
		this.setScene(dialogScene);
		this.show();
	}
}
