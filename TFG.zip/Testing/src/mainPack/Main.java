package mainPack;

import java.util.ArrayList;
import java.util.Random;

import mealyMachine.MealyMachine;
import mealyMachine.Transition;
import testThings.Test;
import testThings.TestComparer;

public class Main {
	public static void main(String args[]){
		
		//System.out.println(m.toDotString());
		
		//VIEW->TESTSCREEN L�NEA 75 QUITAR COMENTARIO
		//VIEW->TESTSCREEN L�NEA 75 QUITAR COMENTARIO
		//VIEW->TESTSCREEN L�NEA 75 QUITAR COMENTARIO
		//VIEW->TESTSCREEN L�NEA 75 QUITAR COMENTARIO
	}
}
