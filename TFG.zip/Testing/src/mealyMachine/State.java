package mealyMachine;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import javafx.util.Pair;


public class State {
	private String id;
	private TransitionFunction func;
	//private ArrayList<Transition> list;
	//Grado de no determinismo, 1->determinista, indica el maximo numero de flechas
	//que salen con mismo input

	public State(String id){
		this.id=id;
		this.func=new TransitionFunction();
	}
	public Transition step(String input){
		//Integer o=list.get(0).getOutput();
		if(func.contains(input))return this.func.step(input);
		else return new Transition(false);
	}
	
	public boolean hasTransition(Integer dest, String string, String string2){
		return func.hasTransition(string, dest, string2);
	}
	
	public Transition getTransition(int pos){
		return this.func.get(pos);
	}
	
	public State() {
		this.func=new TransitionFunction();
	}
	
	
	public int getSize(){
		return func.size();
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public int getNoDet() {
		return this.func.getNoDet();
	}
	
	public void addTransition(Transition t){
		this.func.addTransition(t);
	}
	public State clone(){
		State copia=new State();
		copia.id=new String(this.id);
		copia.func=this.func.clone();
		return copia;
	}
	public String toDotString(){
		return func.toString();
	}
	
	public boolean contains(String input) {
		return this.func.contains(input);
	}
	
	public HashSet<Pair<Integer,String>> acceptedInputs(){
		return func.acceptedInputs();
	}
	
	public ArrayList<String> onlyInputs(){
		HashSet<Pair<Integer,String>> aux=acceptedInputs();
		ArrayList<String> ret=new ArrayList<String>();
		Iterator<Pair<Integer, String>> it=aux.iterator();
		Pair<Integer,String> act;
		while(it.hasNext()) {
			act=it.next();
			ret.add(act.getValue());
		}
		return ret;
	}
	
	public ArrayList<String> outputsFromInput(String inp){
		return this.func.outputsFromInput(inp);
	}
	
	public HashSet<Pair<Integer,String>> setStatesI(String input) {
		return this.func.setStatesI(input);
	}
	
	public Integer after(String input, String output) {
		return this.func.after(input,output);
	}
	
	public ArrayList<Transition> getAll(String input){
		return this.func.getAll(input);
	}
	/*public HashSet<State> setStatesI(String input){
		return this.func.setStatesI(input);
	}*/
	
}