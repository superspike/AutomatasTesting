package mealyMachine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import javafx.util.Pair;


public class State {
	private Integer id;
	private TransitionFunction func;
	//private ArrayList<Transition> list;
	//Grado de no determinismo, 1->determinista, indica el maximo numero de flechas
	//que salen con mismo input
	private Integer nodet=1;

	public State(int id){
		this.id=id;
		this.func=new TransitionFunction();
	}
	public Transition step(String input){
		//Integer o=list.get(0).getOutput();
		if(func.contains(input))return this.func.step(input);
		else return new Transition(false);
	}
	
	public boolean hasTransition(Integer dest, String string, String string2){
		return func.hasTransition(string, dest, string2);
	}
	
	public Transition getTransition(int pos){
		return this.func.get(pos);
	}
	
	public State() {
		this.func=new TransitionFunction();
	}
	
	
	public int getSize(){
		return func.size();
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public void addTransition(Transition t){
		this.func.addTransition(t);
	}
	public State clone(){
		State copia=new State();
		copia.id=new Integer(this.id.intValue());
		copia.func=this.func.clone();
		return copia;
	}
	public String toDotString(){
		return func.toString();
	}
	
	
	
	private class TransitionFunction{
		private HashMap<String,ArrayList<Transition>> mapa;
		private int size;
		
		public TransitionFunction() {
			this.mapa=new HashMap<String,ArrayList<Transition>>();
			size=0;
		}
		
		void addTransition(Transition t) {
			String in,out;
			Integer or,dest;
			in=t.getInput();
			out=t.getOutput();
			or=t.getOrig();
			dest=t.getDest();
			addTransition(or,dest,in,out);
		}
		
		void addTransition(Integer or, Integer dest, String input, String output) {
			if(mapa.containsKey(input)) {
				mapa.get(input).add(new Transition(or,dest,input,output));
			}
			else {
				mapa.put(input, new ArrayList<Transition>());
				mapa.get(input).add(new Transition(or,dest,input,output));
			}
			size++;
		}
		
		public Transition step(String input){
			return mapa.get(input).get(0);
		}
		
		public ArrayList<Transition> getAll(Integer input){
			return mapa.get(input);
		}
		
		public boolean contains(String input) {
			return mapa.containsKey(input);
		}
		
		public Integer size() {
			return size;
		}
		
		public String toString(){
			StringBuilder sb=new StringBuilder();
			Set<Entry<String, ArrayList<Transition>>> lista=mapa.entrySet();
			for(Entry<String, ArrayList<Transition>> caso:lista) {
				for(int i=0;i<caso.getValue().size();i++) {
				sb.append(caso.getValue().get(i).toString());
				}
			}
			return sb.toString();
		}
		
		public TransitionFunction clone() {
			TransitionFunction ret=new TransitionFunction();
			ret.size=size;
			
			Set<Entry<String, ArrayList<Transition>>> lista=mapa.entrySet();
			for(Entry<String, ArrayList<Transition>> caso:lista) {
				for(int i=0;i< caso.getValue().size();i++) {
					ret.addTransition(caso.getValue().get(i).clone());
					ret.size--;//Se le suma al a�adir la transicion, hay que restarlo
				}
			}
			return ret;
		}
		
		public Transition get(int pos) {
			Set<Entry<String, ArrayList<Transition>>> lista=mapa.entrySet();
			int i=0;
			for(Entry<String, ArrayList<Transition>>caso:lista) {
				for(int j=0;j< caso.getValue().size();j++) {
					if(i==pos) {
						return caso.getValue().get(j);
					}
					i++;
				}
			}
			return null;
		}
		
		public boolean hasTransition(String string, Integer in, String string2) {
			if(!mapa.containsKey(in))return false;
			ArrayList<Transition> l=mapa.get(in);
			for(int i=0;i<l.size();i++) {
				if(l.get(i).getInput().equals(in)&&	l.get(i).getDest().equals(string)
						&&l.get(i).getOutput().equals(string2))return true;
			}
			return false;
		}
		
	}
}
