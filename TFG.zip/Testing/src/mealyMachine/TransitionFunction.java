package mealyMachine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javafx.util.Pair;

import java.util.Map.Entry;


public class TransitionFunction{
	//A cada input una lista de transiciones(No determinismo)
	private HashMap<String,ArrayList<Transition>> mapa;
	private int size;
	
	private int nodet=0;
	
	public TransitionFunction() {
		this.mapa=new HashMap<String,ArrayList<Transition>>();
		size=0;
	}
	
	void addTransition(Transition t) {
		String in,out;
		Integer or,dest;
		in=t.getInput();
		out=t.getOutput();
		or=t.getOrig();
		dest=t.getDest();
		addTransition(or,dest,in,out);
	}
	
	void addTransition(Integer or, Integer dest, String input, String output) {
		if(mapa.containsKey(input)) {
			mapa.get(input).add(new Transition(or,dest,input,output));
		}
		else {
			mapa.put(input, new ArrayList<Transition>());
			mapa.get(input).add(new Transition(or,dest,input,output));
		}
		if(mapa.get(input).size()>nodet)nodet=mapa.get(input).size();
		size++;
	}
	
	public Transition step(String input){
		return mapa.get(input).get(0);
	}
	
	public ArrayList<Transition> getAll(Integer input){
		return mapa.get(input);
	}
	
	public boolean contains(String input) {
		return mapa.containsKey(input);
	}
	
	public Integer size() {
		return size;
	}
	
	public String toString(){
		StringBuilder sb=new StringBuilder();
		Set<Entry<String, ArrayList<Transition>>> lista=mapa.entrySet();
		for(Entry<String, ArrayList<Transition>> caso:lista) {
			for(int i=0;i<caso.getValue().size();i++) {
			sb.append(caso.getValue().get(i).toString());
			}
		}
		return sb.toString();
	}
	
	public TransitionFunction clone() {
		TransitionFunction ret=new TransitionFunction();
		ret.size=size;
		
		Set<Entry<String, ArrayList<Transition>>> lista=mapa.entrySet();
		for(Entry<String, ArrayList<Transition>> caso:lista) {
			for(int i=0;i< caso.getValue().size();i++) {
				ret.addTransition(caso.getValue().get(i).clone());
				ret.size--;//Se le suma al a�adir la transicion, hay que restarlo
			}
		}
		return ret;
	}
	
	public Transition get(int pos) {
		Set<Entry<String, ArrayList<Transition>>> lista=mapa.entrySet();
		int i=0;
		for(Entry<String, ArrayList<Transition>>caso:lista) {
			for(int j=0;j< caso.getValue().size();j++) {
				if(i==pos) {
					return caso.getValue().get(j);
				}
				i++;
			}
		}
		return null;
	}
	
	public boolean hasTransition(String string, Integer in, String string2) {
		if(!mapa.containsKey(in))return false;
		ArrayList<Transition> l=mapa.get(in);
		for(int i=0;i<l.size();i++) {
			if(l.get(i).getInput().equals(in)&&	l.get(i).getDest().equals(string)
					&&l.get(i).getOutput().equals(string2))return true;
		}
		return false;
	}

	public ArrayList<String> outputsFromInput(String input){
		ArrayList<String> ret=new ArrayList<String>();
		ArrayList<Transition> aux=mapa.get(input);
		for(int i=0;i<aux.size();i++) {
			ret.add(aux.get(i).getOutput());
		}
		return ret;
	}
	
	public HashSet<Pair<Integer,String>> setStatesI(String input) {
		HashSet<Pair<Integer,String>> ret=new HashSet<Pair<Integer,String>>();
		if(this.contains(input)) {
			Transition caso;
			for(int j=0;j<this.mapa.get(input).size();j++) {
				caso=this.mapa.get(input).get(j);
				ret.add(new Pair<Integer, String>(caso.getDest(),caso.getOutput()));
			}
		}
		return ret;
	}
	
	public HashSet<Pair<Integer,String>> acceptedInputs(){
		HashSet<Pair<Integer,String>> ret=new HashSet<Pair<Integer,String>>();
		Iterator<Entry<String, ArrayList<Transition>>> it = mapa.entrySet().iterator();
		Entry<String,ArrayList<Transition>> act;
		while (it.hasNext()) {
			act=it.next();
			for(int j=0;j<act.getValue().size();j++) {
				ret.add(new Pair<Integer, String>
				(act.getValue().get(j).getDest(),
						act.getKey()));
			}
		}
		return ret;
	}
	
	public int getNoDet() {
		return this.nodet;
	}

	public Integer after(String input, String output) {
		ArrayList<Transition> aux=this.mapa.get(input);
		for(int i=0;i<aux.size();i++) {
			if(aux.get(i).getOutput()==output)return aux.get(i).getDest();
		}
		return -1;
	}
}
