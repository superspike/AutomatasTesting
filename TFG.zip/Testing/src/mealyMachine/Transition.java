package mealyMachine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class Transition {
	private Integer dest;
	private Integer orig;
	private String input;
	private String output;
	
	public Transition(Integer orig, Integer dest, String inp, String outp){
		this.orig=orig;
		this.dest=dest;
		this.input=inp;
		this.output=outp;
	}
	
	public Transition(boolean buena) {
		this.dest=-1;
		this.orig=-1;
	}
	
	public Transition() {}

	public Integer getDest() {
		return dest;
	}

	public void setDest(Integer dest) {
		this.dest = dest;
	}
	public String getInput() {
		return input;
	}
	public void setInput(String input) {
		this.input = input;
	}
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	public Integer getOrig() {
		return orig;
	}
	public void setOrig(Integer orig) {
		this.orig = orig;
	}
	
	public String toString(){
		return this.toDotString();
	}
	
	public String toDotString(){
		StringBuilder sb=new StringBuilder();
		sb.append("s");
		sb.append(this.orig);
		sb.append(" -> ");
		sb.append("s");
		sb.append(this.dest);
		sb.append(" [label=\"");
		sb.append(this.input);
		sb.append(" / ");
		sb.append(this.output);
		sb.append("\"];\n");
		return sb.toString();
	}
	
	
	public Transition clone(){
		Integer or, de;
		String inp, outp;
		or=new Integer(this.orig);
		de=new Integer(this.dest);
		inp=new String(this.input);
		outp=new String(this.output);
		Transition copia=new Transition(or, de, inp, outp);
		return copia;
	}
	
	//Dados ambos sets, a�adimos las strings del input y el output a �stos y creamos la transici�n con sus �ndices
	public static Transition parseTransition(String string,
			ArrayList<String>inputs,ArrayList<String>outputs, HashMap<String, Integer> stateMap){
		Integer or, dest;
		String in, out;
		string=string.replaceAll("\t", "");
		String[] words=string.split("\\[");
		String[] trans=words[0].split("->");
		String ori=trans[0];
		String desti=trans[1];
		String[] inout=words[1].split("\"");
		String inout1=inout[1];
		String[] inout2=inout1.split("/");
		//La string "le�da" la a�adimos a inputSet (el alfabeto de inputs que hemos pasado como argumento)
		//in es el input de la transici�n que estamos parseando, si no est� en el hashmap la a�adimos
		in=inout2[0];
		if(!inputs.contains(in)) {
			inputs.add(in);
		}
		//inputSet.add(in)s
		//Lo mismo que con in=inout[1]
		out=inout2[1];
		if(!outputs.contains(out)) {
			outputs.add(in);
		}
		Integer aux4=stateMap.get(ori);
		Integer aux5=stateMap.get(desti);
		//outputSet.add(out);
		return new Transition(stateMap.get(ori), stateMap.get(desti), in, out);
	}
	
	boolean equals(Transition other){
		return this.dest.equals(other.dest) && this.orig.equals(other.orig)
				&& this.input.equals(other.input) && this.output.equals(other.output);
	}

}
