package mealyMachine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class Transition {
	private Integer dest;
	private Integer orig;
	private String input;
	private String output;
	
	public Transition(Integer orig, Integer dest, String inp, String outp){
		this.orig=orig;
		this.dest=dest;
		this.input=inp;
		this.output=outp;
	}
	
	public Transition(boolean buena) {
		this.dest=-1;
		this.orig=-1;
	}
	
	public Transition() {}

	public Integer getDest() {
		return dest;
	}

	public void setDest(Integer dest) {
		this.dest = dest;
	}
	public String getInput() {
		return input;
	}
	public void setInput(String input) {
		this.input = input;
	}
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	public Integer getOrig() {
		return orig;
	}
	public void setOrig(Integer orig) {
		this.orig = orig;
	}
	
	public String toString(){
		return this.toDotString();
	}
	
	public String toDotString(){
		StringBuilder sb=new StringBuilder();
		sb.append("s");
		sb.append(this.orig);
		sb.append(" -> ");
		sb.append("s");
		sb.append(this.dest);
		sb.append(" [label=\"");
		sb.append(this.input);
		sb.append(" / ");
		sb.append(this.output);
		sb.append("\"];\n");
		return sb.toString();
	}
	
	
	public Transition clone(){
		Integer or, de;
		String inp, outp;
		or=new Integer(this.orig);
		de=new Integer(this.dest);
		inp=new String(this.input);
		outp=new String(this.output);
		Transition copia=new Transition(or, de, inp, outp);
		return copia;
	}
	
	//Dados ambos sets, a�adimos las strings del input y el output a �stos y creamos la transici�n con sus �ndices
	public static Transition parseTransition(String string,
			ArrayList<String>inputs,ArrayList<String>outputs){
		Integer or, dest;
		String in, out;
		String[] words=string.split(" ");
		or=Integer.parseInt(words[0].subSequence(1, words[0].length()).toString());
		dest=Integer.parseInt(words[2].subSequence(1, words[2].length()).toString());
		String[] inout1=words[3].split("\"");
		//La string "le�da" la a�adimos a inputSet (el alfabeto de inputs que hemos pasado como argumento)
		//in es el input de la transici�n que estamos parseando, si no est� en el hashmap la a�adimos
		in=inout1[1];
		if(!inputs.contains(in)) {
			inputs.add(in);
		}
		//inputSet.add(in);
		String[] inout2=words[5].split("\"");
		//Lo mismo que con in=inout[1]
		out=inout2[0];
		if(!outputs.contains(out)) {
			outputs.add(in);
		}
		//outputSet.add(out);
		return new Transition(or, dest, in, out);
	}
	
	boolean equals(Transition other){
		return this.dest.equals(other.dest) && this.orig.equals(other.orig)
				&& this.input.equals(other.input) && this.output.equals(other.output);
	}

}
