package mealyMachine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import javafx.util.Pair;

public class MealyMachine {
	private Integer initialState=0;
	private ArrayList<State> stateList;
	private HashMap<String, Integer> stateMap;
	private ArrayList<String> mutationCode;
	//vamos a tener dos alfabetos, uno de entrada y uno de salida
	//cada alfabeto va a ser un HashMap, podemos mantener los elementos de
	//cada alfabeto �nicos haciendo que sean los values y sus keys sean sus "�ndices"
	private int inAlphabetSize = 3;
	public ArrayList<String> getInAlph() {
		return inAlph;
	}

	public void setInAlph(ArrayList<String> inAlph) {
		this.inAlph = inAlph;
	}

	public ArrayList<String> getOutAlph() {
		return outAlph;
	}

	public void setOutAlph(ArrayList<String> outAlph) {
		this.outAlph = outAlph;
	}

	private int outAlphabetSize = 3;
	private ArrayList<String> inAlph;
	private ArrayList<String> outAlph;
	Scanner reader=new Scanner(System.in);
	Random r=new Random();
	
	//private Translator tr;
	boolean det;
	public int noDet=0;
	//En el constructor en el que generamos la m�quina de mealy aleatoriamente
	//le asignaremos a los elementos del set la string del entero de su �ndice (0-tamAlph-1)
	/*public MealyMachine(int ns, int inAlphSize, int outAlphSize, boolean rand, double completeness){
		this.stateList=new ArrayList<State>();
		this.inAlph = new HashMap<String, Integer>();
		this.outAlph = new HashMap<String, Integer>();
		this.inAlphabetSize = inAlphSize;
		this.outAlphabetSize = outAlphSize;
		if(rand){
			double randTrans;
			int randOut;
			for(int i=0;i<ns;i++){
				this.stateList.add(new State(i));
				for(int j = 0; j < outAlphSize; j++) {
					this.outAlph.put(Integer.toString(j), j);
				}
				for(int j = 0; j < inAlphSize; j++) {
					this.inAlph.put(Integer.toString(j), j);
				}
				for(int j=0; j < inAlphSize; j++){
					//Checkear esto para ver si en transici�n se le asigna el output y tal
					//para que elija uno dentro del outAlphSize
					randOut = r.nextInt(outAlphSize);
					randTrans=Math.random();
					if(randTrans<completeness){
						this.stateList.get(i).addTransition(new Transition(i,r.nextInt(ns), j, randOut));
						//A�adimos el input (j) y el output (el rand generado) de la transici�n a los alfabetos como strings
						//this.inAlph.add(Integer.toString(j));
						//this.outAlph.add(Integer.toString(randOut));
						//Ahora lo hacemos arriba
					}
				}
			}
		}
		else{
			for(int i=0;i<ns;i++){
				this.stateList.add(new State(i));
			}
		}
	}*/
	
	public MealyMachine(int ns, ArrayList<String> inAlph, 
			ArrayList<String> outAlph, boolean rand, double completeness){
		this.stateList=new ArrayList<State>();
		//this.tr=new Translator(inAlph,outAlph);
		this.inAlph=inAlph;
		this.outAlph=outAlph;
		this.inAlphabetSize = inAlph.size();
		this.outAlphabetSize = outAlph.size();
		double randTrans;
		if(rand){
			this.inAlphabetSize=inAlph.size();
			this.outAlphabetSize=outAlph.size();
			
			int randOut;
			for(int i=0;i<ns;i++){
				this.stateList.add(new State(Integer.toString(i)));
				for(int j=0; j < inAlphabetSize; j++){
					//Checkear esto para ver si en transici�n se le asigna el output y tal
					//para que elija uno dentro del outAlphSize
					randOut = r.nextInt(outAlphabetSize);
					randTrans=Math.random();
					if (randTrans<=completeness){
						this.stateList.get(i).addTransition(new Transition(i,r.nextInt(ns), this.inAlph.get(j)
								, this.outAlph.get(randOut)));

						//A�adimos el input (j) y el output (el rand generado) de la transici�n a los alfabetos como strings
						//this.inAlph.add(Integer.toString(j));
						//this.outAlph.add(Integer.toString(randOut));
					}
				}
			}
		}
		else{
			for(int i=0;i<ns;i++){
				this.stateList.add(new State(Integer.toString(i)));
			}
		}
	}
	
	//Constructor creado para testear cosas
	//en un entorno controlado
	public MealyMachine(int ns) {
		this.stateList=new ArrayList<State>();
		ArrayList<String> in=new ArrayList<String>();
		ArrayList<String> out=new ArrayList<String>();
		in.add("0");
		in.add("1");
		out.add("hola");
		out.add("adios");
		this.inAlphabetSize = 2;
		this.outAlphabetSize = 2;
		String nom;
		String ape;
		
		System.out.println("Numeruelo");
		Integer inti = reader.nextInt();
		System.out.println("Introduce tu puto nombre de mierda:");
		nom = reader.nextLine();
		System.out.println("Introduce tu apellido ahora imb�cil: ");
		ape = reader.nextLine();
		System.out.println("Te llamas " + nom + " " + ape);
		
		this.stateList.add(new State("0"));
		this.stateList.get(0).addTransition(new Transition(0, 0, "0", "hola"));
		this.stateList.get(0).addTransition(new Transition(0, 1, "1", "adios"));
		
		this.stateList.add(new State("1"));
		this.stateList.get(1).addTransition(new Transition(1, 0, "1", "adios"));
		this.stateList.get(1).addTransition(new Transition(1, 1, "0", "hola"));
	}
	
	//Al parsear las transiciones podemos ir generando el set llamando a un addToSet o algo as�
	//porque en el archivo o lo que sea del que leamos los inputs/outputs pueden estar en otro formato que 
	//no sean ints, entcones nos renta que  medida que vayamos leyendo y encontrando inputs/outputs los
	//a�adamos a sus correspondientes sets y que el orden en el que los parseemos se corresponda con el entero 
	//que le vamos a asignar internamente (0<->n-1)
	public MealyMachine(String s) throws Exception{
		stateMap=new HashMap<String,Integer>();
		this.stateList=new ArrayList<State>();
		//this.inAlph = new HashSet<String>();
		//this.outAlph = new HashSet<String>();
		ArrayList<String> inputs=new ArrayList<String>();
		ArrayList<String> outputs=new ArrayList<String>();
		inAlph=new ArrayList<String>();
		outAlph=new ArrayList<String>();
		String[] words=s.split("\n");
		String[] intro=words[0].split(" ");
		int j=1;
		if(!intro[0].equalsIgnoreCase("digraph"))throw new Exception();		
		while(words[j].equals(""))
			j++;
		String aux=words[j].replaceAll(" ", "").replaceAll("\t", "");
		String[] aux2=aux.split("\\[");
		if(aux.split("\\[")[0].equalsIgnoreCase("__start0"))j++;		
		
		while(words[j].equals(""))
			j++;

		aux=words[j].replaceAll("\\s", "");
		if(aux.split("->")[0].equalsIgnoreCase("__start0"))j++;
		

		while(words[j].equals(""))
			j++;
		int k=0;
		aux=words[j].replaceAll(" ", "").replaceAll("\t", "");
		aux2=aux.split("\\[");
		while(aux2[0].split("->").length==1){
			stateMap.put(aux2[0], k);
			stateList.add(new State(Integer.toString(k)));
			k++;
			j++;
			while(words[j].equals(""))j++;
			aux=words[j].replaceAll(" ", "").replaceAll("\t", "");
			aux2=aux.split("\\[");
		}

		while(words[j].equals(""))
			j++;
		//Entrar a la funci�n parseTransition para desde ah� poder a�adir los elementos a los input y output sets
		//usando getters
		aux=words[j].replaceAll(" ", "").replaceAll("\t", "");
		aux2=aux.split("\\[");
		while(aux2.length>1){
			this.addTransition(Transition.parseTransition(aux, 
					inputs, outputs,stateMap));
			j++;
			while(words[j].equals(""))j++;
			aux=words[j].replaceAll(" ", "").replaceAll("\t", "");
			aux2=aux.split("\\[");
		}
		for(int h=0;h<stateList.size();h++) {
			if(stateList.get(h).getNoDet()>noDet)noDet=stateList.get(h).getNoDet();
		}

		this.inAlphabetSize = inputs.size();
		this.outAlphabetSize = outputs.size();
		inAlph=inputs;
		outAlph=outputs;
		//this.tr=new Translator(inAlph,outAlph);
	}
	
	public MealyMachine(int n, int inAlphSize, int outAlphSize){
		this.stateList=new ArrayList<State>();
		this.inAlphabetSize = inAlphSize;
		this.outAlphabetSize = outAlphSize;
		for(int i=0;i<n;i++){
			stateList.add(new State(Integer.toString(i)));
		}
		Integer or, dest;
		String in, out;
		int inAdded = 0;
		int outAdded = 0;
		int opcion=1;
		ArrayList<String> inAlph=new ArrayList<String>();
		ArrayList<String> outAlph=new ArrayList<String>();
		while(opcion!=0){
			System.out.println("0-End");
			System.out.println("1-Introduce Transition");
			opcion=reader.nextInt();
			if(opcion==1){
				//La transici�n funciona con enteros, pero el usuario va a introducir un String para in/out
				//Metemos esa string en el Set de alfabeto correspondiente, y el valor entero que le pasamos 
				//a addTransition es el �ndice de esas strings en sus correspondientes Sets
				System.out.println("Introduce el estado origen.");
				or=reader.nextInt();
				reader.nextLine();
				System.out.println("Introduce el estado destino.");
				dest=reader.nextInt();
				reader.nextLine();
				System.out.println("Introduce la entrada.");
				in=reader.nextLine();
				System.out.println("Introduce la salida.");
				out=reader.nextLine();
				//Si el input introducido no est� todav�a en el mapa, si es el k-�simo elemento
				//le vamos a asignar el �ndice (valor) k-1, que es el map.size() antes de a�adirlo
				if(!inAlph.contains(in)) {
					//this.inAlph.put(in, this.inAlph.size());
					inAlph.add(in);
					inAdded++;
				}
				if(!outAlph.contains(out)) {
					//this.outAlph.put(ouy, this.outAlph.size());
					outAlph.add(out);
					outAdded++;
				}
				this.addTransition(new Transition(or, dest, in, out));
			}
		}
		//this.tr=new Translator(inAlph,outAlph);
		System.out.println("inAplh size " + inAlph.size());
		System.out.println("outAplh size " + outAlph.size());
		
		this.complete();
	}

	private void complete(){
		System.out.println("�Hace falta completar el automata?Es decir");
		System.out.println("poner estado sumidero");
	}
	
	public MealyMachine() {}


	/**
	 * set type to 0 to mutate outputs or 1 to mutate destinies
	 * @param type 
	 * @param prob 
	 * @return 
	 */
	public MealyMachine generateMutant(int type, double prob){
		MealyMachine ret=this.clone();
		if(type==0){
				ret.mutateOutput();
			}
		else if(type==1){
				ret.mutateDestiny();
			}
		else if(type==2) {
			ret.mutateSpecial1(prob);
		}
		return ret;
	}
	
	public ArrayList<MealyMachine> generateAllMutants(int type){
		Random r=new Random();
		MealyMachine caso;
		ArrayList<MealyMachine> ret=new ArrayList<MealyMachine>();
		if(type==0) {
			for(int i=0;i<stateList.size();i++) {
				for(int j=0;j<stateList.get(i).getSize();j++) {
					for(int k=0;k<outAlphabetSize;k++) {
						if(!outAlph.get(k).equals(
								this.stateList.get(i).getTransition(j).getOutput())) {
							caso=this.clone();
								caso.stateList.get(i).getTransition(j).
							setOutput(this.outAlph.get(k));
							ret.add(caso);
							caso.mutationCode=new ArrayList<String>();
							caso.mutationCode.add(Integer.toString(0));
							caso.mutationCode.add(Integer.toString(i));
							caso.mutationCode.add(Integer.toString(j));
							caso.mutationCode.add(Integer.toString(k));
						}
					}
				}
			}
		}
		else if(type==1) {
			for(int i=0;i<stateList.size();i++) {
				for(int j=0;j<stateList.get(i).getSize();j++) {
					for(int k=0;k<stateList.size();k++) {
						if(k!=this.stateList.get(i).getTransition(j).getDest().intValue()) {
							caso=this.clone();
							this.stateList.get(i).getTransition(j).
							setDest(k);
							ret.add(caso);
							caso.mutationCode=new ArrayList<String>();
							caso.mutationCode.add(Integer.toString(1));
							caso.mutationCode.add(Integer.toString(i));
							caso.mutationCode.add(Integer.toString(j));
							caso.mutationCode.add(Integer.toString(k));
						}
					}
				}
			}
		}
		return ret;
	}
	
	public MealyMachine applyMutation(int type, int state, int trans, Integer dat) {
		MealyMachine mm=this.clone();
		if(type==1) {
			mm.stateList.get(state).getTransition(trans).
				setDest(dat);
		}else if(type==0) {
			mm.stateList.get(state).getTransition(trans).
				setOutput(this.outAlph.get(dat));
		}
		return mm;
	}
	
	public void mutateOutput(){
		Random r=new Random();
		int randomInt1=r.nextInt(this.stateList.size());//Seleccionamos un estado aleatorio
		while(this.stateList.get(randomInt1).getSize()==0) {
			randomInt1=r.nextInt(this.stateList.size());//Seleccionamos un estado aleatorio
		}
		int randomInt2=r.nextInt(this.stateList.get(randomInt1).getSize());//Seleccionamos una transicion aleatoria dentro de ese estado aleatorio
		int randomInt3=r.nextInt(this.outAlphabetSize);
		//System.out.println(copia.stateList.get(randomInt1).getTransition(randomInt2).getOutput());
		//CREO QUE NO HACE FALTA QUE CAMBIEMOS NADA EN LA SGUIENTE PORQUE INTERNAMENTE SEGUIMOS TRATANDO LOS INPUTS/OUTS
		//COMO ENTEROS, S�LO QUE TENEMOS QUE TENER ALGUNA MANERA DE TRADUCIRLOS, AS� QUE SETTEAR EL OUTPUT COMO INT
		//PUEDE QUE EST� BIEN? TENGO QUE COMPROBARLO
		this.stateList.get(randomInt1).getTransition(randomInt2).
			setOutput(this.outAlph.get(randomInt3));
		this.mutationCode=new ArrayList<String>();
		this.mutationCode.add(Integer.toString(0));
		this.mutationCode.add(Integer.toString(randomInt1));
		this.mutationCode.add(Integer.toString(randomInt2));
		this.mutationCode.add(Integer.toString(randomInt3));
		//System.out.println(copia.stateList.get(randomInt1).getTransition(randomInt2).getOutput());
		//System.out.println(randomInt3);
		//System.out.println();
	}
	public void mutateDestiny(){
		int randomInt1=r.nextInt(this.stateList.size());//Seleccionamos un estado aleatorio
		while(this.stateList.get(randomInt1).getSize()==0) {
			randomInt1=r.nextInt(this.stateList.size());//Seleccionamos un estado aleatorio
		}
		int randomInt2=r.nextInt(this.stateList.get(randomInt1).getSize());//Seleccionamos una transicion aleatoria dentro de ese estado aleatorio
		int randomInt3=r.nextInt(this.stateList.size());//Seleccionamos un estado aleatorio como destino de la transicion elegida
		//System.out.println(copia.stateList.get(randomInt1).getTransition(randomInt2).getDest());
		this.stateList.get(randomInt1).getTransition(randomInt2).setDest(randomInt3);
		//System.out.println(randomInt3);
		//System.out.println(copia.stateList.get(randomInt1).getTransition(randomInt2).getDest());
		//System.out.println();
		this.mutationCode=new ArrayList<String>();
		this.mutationCode.add(Integer.toString(1));
		this.mutationCode.add(Integer.toString(randomInt1));
		this.mutationCode.add(Integer.toString(randomInt2));
		this.mutationCode.add(Integer.toString(randomInt3));
	}
	public void mutateSpecial1(double prob) {
		int i=this.getNumStates();
		Integer estadoComunicador=r.nextInt(this.getNumStates());
		this.stateList.add(new State(Integer.toString(i)));

		this.stateList.get(estadoComunicador).addTransition(
				new Transition(estadoComunicador,i,
						this.inAlph.get(r.nextInt(this.getInAlphSize())),
						this.outAlph.get(r.nextInt(this.getOutAlphSize()))));
		double caso;
		for(int j=0;j<this.inAlphabetSize;j++) {
			caso=r.nextDouble();
			if(caso<=prob) {
				this.stateList.get(i).addTransition(new Transition(
						i,r.nextInt(i+1), this.inAlph.get(r.nextInt(this.inAlphabetSize)),
						this.outAlph.get(r.nextInt(this.outAlphabetSize))));
			}
		}
	}
	
	public Transition step(int cur, String input){
		return stateList.get(cur).step(input);
	}
	
	//private void generateMealy(String s) {}
	
	
	public void addTransition(Transition t){
		this.stateList.get(t.getOrig()).addTransition(t);
		if(stateList.get(t.getOrig()).getNoDet()>this.noDet)
			this.noDet=stateList.get(t.getOrig()).getNoDet();
	}

	public void addTransition(Integer s0, Integer s1, String in, String out) {
		this.stateList.get(s0).addTransition(new Transition(
				s0,s1,in,out)
		);
	}
	
	public MealyMachine clone(){
		MealyMachine ret=new MealyMachine();
		ret.inAlphabetSize=this.inAlphabetSize;
		ret.initialState=this.initialState;
		ret.stateList=new ArrayList<State>();
		ret.inAlph=(ArrayList<String>) this.inAlph.clone();
		ret.outAlph=(ArrayList<String>) this.outAlph.clone();
		ret.inAlphabetSize=this.inAlphabetSize;
		ret.outAlphabetSize=this.outAlphabetSize;
		//ret.tr=this.tr.clone();
		for(int i=0;i<stateList.size();i++){
			ret.stateList.add(this.stateList.get(i).clone());
		}
		return ret;
	}
	
	public String toDotString(){
		StringBuilder sb=new StringBuilder();
		sb.append("digraph g {\n");
		sb.append(" __start0 [label=\"\" shape=\"none\"]\n");
        sb.append("__start0 -> \"s0\";\n");
		for(int i=0;i<this.stateList.size();i++){
			sb.append("s");
			sb.append(i);
			sb.append("[shape=\"circle\" label=\"");
			sb.append("s");
			sb.append(i);
			sb.append("\"];");
			sb.append("\n");
		}
		for(int i=0;i<this.stateList.size();i++){
			sb.append(this.stateList.get(i).toDotString());
		}
		sb.append("}\n");
		//sb.append(alphTranslations());
		return sb.toString();
	}
	public String toString(){
		return this.toDotString();
	}
	public Integer getNumStates(){
		return this.stateList.size();
	}
	public Integer getInAlphSize(){
		return this.inAlphabetSize;
	}
	public Integer getOutAlphSize() {
		return this.outAlphabetSize;
	}
	//Searches a given set for an element.
	//Returns its index if it's in the set or -1 if it isn't
	//Deber�a hacer una clase que implemente Set y que tenga este m�todo aparte 
	//pero ya para otro momento
	public Integer getSetIndex(Set<String> set, String element) {
		int index = 0;
		for(String item:set){
			if(item.equals(element)) {
				return index;
			}
			index++;
		}
		return -1;
	}
	/*
	public String inAlphTrans() {
		StringBuilder sb = new StringBuilder();
		sb.append("Input mappings = ");
		sb.append(inAlph);
		sb.append("\n");
		return sb.toString();
	}
	public String outAlphTrans() {
		StringBuilder sb = new StringBuilder();
		sb.append("Output mappings = ");
		sb.append(outAlph);
		sb.append("\n");
		return sb.toString();
	}
	public String alphTranslations() {
		StringBuilder sb = new StringBuilder();
		sb.append(inAlphTrans());
		sb.append(outAlphTrans());
		return sb.toString();
	}
	*/
	public boolean hasTransition(Integer s0, Integer s1, String string, String string2){
		return this.stateList.get(s0).hasTransition(s1, string, string2);
	}
	
	
	
	//True if this machine conforms to m2, i.e m2 is contained here
	//No lo implementamos todavia en la interfaz porque no sabemos si es lo que pide.
	public boolean conforms(MealyMachine m2){
		Transition t;
		for(int i=0;i<m2.getNumStates();i++){
			for(int j=0;j<m2.stateList.get(i).getSize();j++){
				t=m2.stateList.get(i).getTransition(j);
				if(!this.hasTransition(t.getOrig(), t.getDest(), 
						t.getInput(), t.getOutput()))return false;
			}
		}
		return true;
	}

	public String inpIntToStr(Integer a) {
		return inAlph.get(a);
	}
	public String outIntToStr(Integer a) {
		return outAlph.get(a);
	}
	/*
	public Integer inpStrToInt(String a) {
		return tr.inpTrans(a);
	}
	public Integer outStrToInt(String a) {
		return tr.outTrans(a);
	}*/


	public HashSet<Pair<Integer,String>> acceptedInputs(Integer state){
		return this.stateList.get(state).acceptedInputs();
	}
	
	public ArrayList<ArrayList<String>> inputsLonK(int k){
		TreeAux tree=new TreeAux("", initialState);
		inputsLonKRec(k,tree);
		ArrayList<String> aux1=new ArrayList<String>();
		HashSet<ArrayList<String>> aux2=new HashSet<ArrayList<String>>();
		dfs(tree,aux1,aux2);
		return new ArrayList<ArrayList<String>>(aux2);
	}
	
	public void dfs(TreeAux tree, ArrayList<String> acum, 
			HashSet<ArrayList<String>> inputs) {
		if(tree.getChilds().size()==0) {
			if(!inputs.contains(acum))inputs.add(acum);
		}
		else {
			ArrayList<TreeAux> lista=tree.getChilds();
			ArrayList<String> acum2;
			for(int i=0;i<lista.size();i++) {
				acum2=(ArrayList<String>) acum.clone();
				acum2.add(lista.get(i).getInp());
				dfs(lista.get(i),acum2,inputs);
				}
		}
	}
	
	
	public void inputsLonKRec(int k,TreeAux arbol){
		if(k==0)return;
		else {
			arbol.addChilds(this);
			ArrayList<TreeAux> lista=arbol.getChilds();
			for(int i=0;i<lista.size();i++) {
				inputsLonKRec(k-1,lista.get(i));
			}
		}
	}
	
	public HashSet<Pair<Integer,String>> setStatesI(Integer state, String inp) {
		if(this.stateList.get(state).contains(inp)) {
			return this.stateList.get(state).setStatesI(inp);
		}
		else {
			return new HashSet<Pair<Integer,String>>();
		}
	}
	
	public boolean det() {
		return noDet<=1;
	}

	public ArrayList<String> getInputsFromState(Integer state){
		return this.stateList.get(state).onlyInputs();
	}

	public ArrayList<String> getOutputsFromStateInput(Integer state,String input){
		return this.stateList.get(state).outputsFromInput(input);
	}
	
	public Integer after(Integer state, String input,String output) {
		return this.stateList.get(state).after(input, output);
	}
	
	public ArrayList<ArrayList<String>> generateOutputs(ArrayList<String> inps){
		ArrayList<ArrayList<String>> ret=new ArrayList<ArrayList<String>>();
		ArrayList<Pair<ArrayList<String>, State>> lista=
				new ArrayList<Pair<ArrayList<String>, State>>();
		ArrayList<Pair<ArrayList<String>, State>> listaAux=
				new ArrayList<Pair<ArrayList<String>, State>>();
		lista.add(new Pair<ArrayList<String>, State>
			(new ArrayList<String>(), this.stateList.get(initialState)));
		
		ArrayList<String> outTemp=new ArrayList<String>();
		for(int i=0;i<inps.size();i++) {

			for(int j=0;j<lista.size();j++) {
				Pair<ArrayList<String>, State> caso=lista.get(j);
				ArrayList<Transition> aux=
						caso.getValue().getAll(inps.get(i));
				if(aux!=null) {
					for(int k=0;k<aux.size();k++) {
						outTemp=(ArrayList<String>) caso.getKey().clone();
						outTemp.add(aux.get(k).getOutput());
						Integer dest=aux.get(k).getDest();
						listaAux.add(new Pair<ArrayList<String>, State>
							(outTemp,stateList.get(dest)));
					}
				}
			}
			
			lista=listaAux;
			listaAux=new ArrayList<Pair<ArrayList<String>, State>>();
		}
		
		for(int l=0;l<lista.size();l++) {
			ret.add(lista.get(l).getKey());
		}
		return ret;
	}
	
	public int numberOfTransitions() {
		int ret=0;
		for(int i=0;i<stateList.size();i++) {
			ret+=stateList.get(i).getSize();
		}
		return ret;
	}
	
	public String getMutCode() {
		String ret="";
		for(int i=0;i<this.mutationCode.size()-1;i++) {
			ret+=mutationCode.get(i)+" ";
		}
		ret+=mutationCode.get(this.mutationCode.size()-1);
		return ret;
	}
	
	
	public ArrayList<String> randomInputChain(int size){
		ArrayList<String> ret=new ArrayList<String>();
		Random r=new Random();
		int act=this.initialState;
		String s;
		Transition t;
		for(int i=0;i<size && stateList.get(act).getSize()>0;i++) {
			t=this.stateList.get(act).getTransition(
					r.nextInt(stateList.get(act).getSize()));
			ret.add(t.getInput());
			act=t.getDest();
		}
		return ret;
	}
	
}
