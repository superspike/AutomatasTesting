package mealyMachine;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;


import javafx.util.Pair;

public class TreeAux {
	private String inp;
	private Integer state;
	private ArrayList<TreeAux> hijos;
	
	public TreeAux(String a, Integer b) {
		this.inp=a;
		this.state=b;
		hijos=new ArrayList<TreeAux>();
	}
	
	public void addChilds(MealyMachine m) {
		HashSet<Pair<Integer, String>> aux=m.acceptedInputs(state);
		Iterator<Pair<Integer, String>> it=aux.iterator();
		Pair<Integer, String> act;
		while(it.hasNext()) {
			act=it.next();
			hijos.add(new TreeAux(
					act.getValue(),act.getKey()
					));
		}
	}
	public ArrayList<TreeAux> getChilds(){
		return hijos;
	}

	public String getInp() {
		return inp;
	}

	public void setInp(String inp) {
		this.inp = inp;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}
}
