package mealyMachine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class Translator {
	private HashMap<String, Integer> outAlph;
	private HashMap<String, Integer> inpAlph;
	private HashMap<Integer, String> outAlphInv;
	private HashMap<Integer, String> inpAlphInv;
	
	public Translator(HashMap<String,Integer> mapIn, HashMap<String,Integer>mapOut) {
		this.inpAlph=mapIn;
		this.outAlph=mapOut;
		this.outAlphInv=new HashMap<Integer,String>();
		this.inpAlphInv=new HashMap<Integer,String>();
		for (Entry<String, Integer> entry : inpAlph.entrySet()) {
			   inpAlphInv.put(entry.getValue(), entry.getKey());
			}
		for (Entry<String, Integer> entry : outAlph.entrySet()) {
			   outAlphInv.put(entry.getValue(), entry.getKey());
			}
	}
	
	public Translator(ArrayList<String> inputs, ArrayList<String> outputs) {
		inpAlph=new HashMap<String, Integer>();
		outAlph=new HashMap<String, Integer>();
		inpAlphInv=new HashMap<Integer, String>();
		outAlphInv=new HashMap<Integer, String>();
		for(int i=0;i<inputs.size();i++) {
			inpAlph.put(inputs.get(i), i);
			inpAlphInv.put(i, inputs.get(i));
		}
		for(int i=0;i<outputs.size();i++) {
			outAlph.put(outputs.get(i), i);
			outAlphInv.put(i, outputs.get(i));
		}
	}

	public Integer inpTrans(String a) {
		return this.inpAlph.get(a);
	}
	
	public Integer outTrans(String a) {
		return this.outAlph.get(a);
	}

	public String inpTransInv(Integer a) {
		return this.inpAlphInv.get(a);
	}
	
	public String outTransInv(Integer a) {
		return this.outAlphInv.get(a);
	}
	
	public Translator clone() {
		ArrayList<String> inps=new ArrayList<String>();
		ArrayList<String> outs=new ArrayList<String>();
		inps.addAll(this.inpAlph.keySet());
		outs.addAll(this.outAlph.keySet());
		return new Translator(inps,outs);
	}
	
}
