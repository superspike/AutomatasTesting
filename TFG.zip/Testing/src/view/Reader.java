package view;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Reader {
	public static String readFile(File file){
		StringBuilder sb=new StringBuilder();
		try {
			BufferedReader br = new BufferedReader(new FileReader(file)); 
			String str; 
			while ((str = br.readLine()) != null) {
				sb.append(str); 
				sb.append("\n");
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return sb.toString();
	}
}
