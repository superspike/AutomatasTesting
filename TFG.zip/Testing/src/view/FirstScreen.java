package view;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import mealyMachine.MealyMachine;
import view.alphView.AlphList;

public class FirstScreen extends MealyCreatorGroup {

	private FileChooser fc;
	private Stage sta;
	private Button b1;
	private Button b2;
	private Button b3;
	private Button b4;
	private Button b5;
	
	private AlphList inp;
	private AlphList out;

	private Spinner<Integer> s1; //Num states spinner
	private Spinner<Double> s5; //% of transitions spinner
	private SpinnerValueFactory<Integer> vf1; //Num states spinner value factory
	private SpinnerValueFactory<Integer> vf2; //Input alph size spinner value factory
	private SpinnerValueFactory<Integer> vf3; //Output alph size spinner value factory
	private SpinnerValueFactory<Double> vf4; //%of transitions in random automaton
	private Text t1; 
	private Text t2;
	private Text t3;
	private Text t4;
	private Text t5;
	private TextArea autoDot;
	private Container c;
	private GridPane gp;
	private boolean created=false;
	
	public FirstScreen(Stage st, Container co){
		this.c=co;
		this.sta=st;
		fc=new FileChooser();
		b1=new Button("Create Random automaton");
		b2=new Button("Create Manual automaton");
		b3=new Button("Begin test");
		b4=new Button("Select file");
		s1=new Spinner<Integer>();
		s5=new Spinner<Double>();
		vf1=new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10, 3);
		vf2=new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10, 3);
		vf3=new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10, 3);
		vf4=new SpinnerValueFactory.DoubleSpinnerValueFactory(0, 1, 0.7,0.05);
		t1=new Text("Number of states");
		t5=new Text("% of transitions   ");
		t2=new Text("Set up input alphabet ");
		t3=new Text("Set up output alphabet");
		t4=new Text("Dot automata");
		autoDot=new TextArea();
		autoDot.setMaxWidth(300);
		autoDot.setMaxHeight(100);
		s1.setValueFactory(vf1);
		s5.setValueFactory(vf4);
		gp=new GridPane();
		b1.setOnAction(
	            new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) {
	                		
	                		c.setMm(new MealyMachine(
	                				s1.getValue(), inp.getAlph(),out.getAlph(), true,s5.getValue()));
	                		autoDot.setText(c.getMm().toDotString());
	                		created =true;
	                    }
	            });
		b2.setOnAction(
	            new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) {
	                		Scene sc=new Scene(new CreateManualAutomatonScreen
	                				(s1.getValue(),inp.getAlph(), out.getAlph(), sta,c), 800,600);
	                		sta.setScene(sc);
	                		created=true;
	                		sta.show();
	                    }
	            });
		b3.setOnAction(
	            new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) {
	                		if(c.getMm()!=null){
	                			Scene sc=new Scene(new TestingScreen
	                				(sta,c),800,600);
	                			sta.setScene(sc);
	                			sta.show();
	                		}
	                		else System.out.println("sin crear");
	                	}
	            });
		this.b4.setOnAction(
	            new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) { 
	                	String texto="";
	                	File file = fc.showOpenDialog(sta);
	                	if (file != null) {
                        //openFile(file);
	                		texto=readFile(file);
	                	}
	                	autoDot.setText(texto);
	                }
	            });
		out=new AlphList();
		inp=new AlphList();
		
		HBox h1=new HBox();
		h1.setSpacing(15);
		h1.getChildren().add(t1);
		h1.getChildren().add(s1);
		
		HBox h2=new HBox();
		h2.setSpacing(15);
		h2.getChildren().add(t5);
		h2.getChildren().add(s5);
		
		StackPane sp1=new StackPane();
		HBox h3=new HBox();
		h3.setSpacing(15);
		h3.getChildren().add(t2);
		h3.getChildren().add(inp);
		StackPane.setMargin(h3, new Insets(5,5,5,5) );
		sp1.getChildren().add(h3);
		sp1.setBorder(new Border(new BorderStroke(Color.LIGHTGREY, 
	            BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
		
		StackPane sp2=new StackPane();
		HBox h4=new HBox();
		h4.setSpacing(15);
		h4.getChildren().add(t3);
		h4.getChildren().add(out);
		StackPane.setMargin(h4, new Insets(5,5,5,5) );
		sp2.getChildren().add(h4);
		sp2.setBorder(new Border(new BorderStroke(Color.LIGHTGREY, 
	            BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
		
		HBox h5=new HBox();
		h5.setSpacing(15);
		h5.getChildren().add(t4);
		h5.getChildren().add(autoDot);
		
		HBox h6=new HBox();
		h6.getChildren().add(b3);

		VBox v1=new VBox();
		v1.setSpacing(15);
		v1.getChildren().add(h1);
		v1.getChildren().add(h2);
		v1.getChildren().add(sp1);
		v1.getChildren().add(sp2);
		HBox h7=new HBox();
		h7.setSpacing(10);
		HBox.setMargin(b1, new Insets(10,10,10,10));
		HBox.setMargin(b2, new Insets(10,10,10,10));
		h7.getChildren().add(b1);
		h7.getChildren().add(b2);
		v1.getChildren().add(h7);
		v1.getChildren().add(h5);
		v1.getChildren().add(h6);
		VBox.setMargin(h1, new Insets(5,5,5,5));
		VBox.setMargin(h2, new Insets(5,5,5,5));
		VBox.setMargin(sp1, new Insets(5,5,5,5));
		VBox.setMargin(sp2, new Insets(5,5,5,5));
		VBox.setMargin(h5, new Insets(5,5,5,5));
		VBox.setMargin(h6, new Insets(5,5,5,5));
		this.getChildren().add(v1);
	}

	private String readFile(File file){
		  StringBuilder sb=new StringBuilder();
		  try {
			  BufferedReader br = new BufferedReader(new FileReader(file)); 
			  String str; 
			while ((str = br.readLine()) != null) {
			   sb.append(str); 
			   sb.append("\n");
			  }
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return sb.toString();
	}
	
	public void writeAuto(){
		this.autoDot.setText(this.c.getMm().toDotString());
	}
	
	@Override
	public MealyMachine getMealyMachine() {
		return c.getMm();
	}
	
}
/*
 * TENGO QUE ARREGLAR LAS COSAS DE VIEW AHORA QUE HE CAMBIADO LA ESTRUCTURA DEL C�GIDO CON LOS SETS Y DEM�S
 * L 64-65 FirstScreen
 * L 101 FirstScreen
 * L 58 CreateManualAutomatonScreen
 * 
 * TENGO QUE MIRAR LAS FUNCIONES QUE CREAN LAS STRINGS QUE DESCRIBEN LAS M�QUINAS Y LAS QUE LAS PARSEAN
 * PARA ADAPTARLAS A QUE USEN LOS SETS
 * 
 * La maquina no tiene porque ser completa DONE
 * Alfabeto de input y de output DONE
 * Testear con maquina y sin maquina(solo con test), generar tests(Tener formato interno input-ouput)., 
 * Problema del mutante quivalente 
 * Conformance DONE?
 * Generar test de longitud determinada DONE
 * Generar test de forma aleatoria con n inputs EN TOTAL, evitar test redundantes DONE a medias
 * Esta todo excepto lo del mutante equivalente y los test redundantes.
 * 
 * Mutacion nueva: Estado nuevo que pueda ser normal o error.
 * 
*/