package view.alphView;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class AlphList extends Group{
	private TextArea t;
	private Button addElem;
	private Button delete;
	private ListView<String> l;
	private GridPane gp;
	
	public AlphList(){
		addElem=new Button("Add to alphabet");
		delete=new Button("Delete element");
		addElem.setOnAction(new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) {
	                		l.getItems().add(t.getText());
	                		t.setText("");
	                    }
	            });
		delete.setOnAction(new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) {
	                    int selectedIdx = l.getSelectionModel().getSelectedIndex();
	                    if(selectedIdx!=-1){
	                    	
	                    	 final int newSelectedIdx =
	                                 (selectedIdx == l.getItems().size() - 1)
	                                         ? selectedIdx - 1
	                                         : selectedIdx;
	                    	
	                    	 l.getItems().remove(selectedIdx);
	                    	 l.getSelectionModel().select(newSelectedIdx);
	                         //removes the player for the array
	                    }
	                    }
	            });
		t=new TextArea();
		t.setMaxHeight(25);
		t.setMaxWidth(100);
		t.setMinHeight(25);
		t.setMinWidth(100);
		delete.setMaxHeight(25);
		delete.setMinHeight(25);
		delete.setMinWidth(200);
		delete.setMaxWidth(200);
		l=new ListView<String>();
		l.setMaxHeight(100);
		gp=new GridPane();
		gp.add(addElem, 1, 0);
		gp.add(t,0,0);
		gp.add(delete,0,1);
		//gp.add(l,1,1);
		gp.setMaxHeight(200);
		gp.setMaxWidth(500);
		HBox h1=new HBox();
		HBox h2=new HBox();
		VBox v1=new VBox();
		v1.setSpacing(30);
		h2.setSpacing(20);
		h1.getChildren().add(t);
		VBox.setMargin(h1, new Insets(10,0,0,0));
		h1.getChildren().add(addElem);
		v1.getChildren().add(h1);
		v1.getChildren().add(delete);
		h2.getChildren().add(v1);
		h2.getChildren().add(l);
		this.getChildren().add(h2);
	}
	
	public ArrayList<String> getAlph(){
		return new ArrayList<String>(this.l.getItems());
	}
	
}
