package view;

import mealyMachine.MealyMachine;
import javafx.scene.Group;

public abstract class MealyCreatorGroup extends Group {
	public abstract MealyMachine getMealyMachine();
}
