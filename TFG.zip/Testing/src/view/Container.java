package view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Random;

import testThings.TestComparer;
import mealyMachine.MealyMachine;

public class Container {
	public FirstScreen getFs() {
		return fs;
	}

	public void setFs(FirstScreen fs) {
		this.fs = fs;
	}

	public CreateManualAutomatonScreen getCma() {
		return cma;
	}

	public void setCma(CreateManualAutomatonScreen cma) {
		this.cma = cma;
	}

	private MealyMachine mm;
	private FirstScreen fs;
	private CreateManualAutomatonScreen cma;
	private TestingScreen ts;
	private TestComparer tc;

	public MealyMachine getMm() {
		return mm;
	}

	public void setMm(MealyMachine mm) {
		this.mm = mm;
	}

	
	public void changeText(){
		this.fs.writeAuto();
	}

	public TestingScreen getTs() {
		return ts;
	}

	public void setTs(TestingScreen ts) {
		this.ts = ts;
	}

	public TestComparer getTc() {
		return tc;
	}

	public void setTc(TestComparer tc) {
		this.tc = tc;
	}
	
	public ArrayList<String> generateRandomTest(int size){
		Random r=new Random();
		Integer i;
		ArrayList<String> ret=new ArrayList<String>();
		for(int j=0;j<size;j++){
			i=r.nextInt(this.mm.getInAlphSize());
			ret.add(mm.inpIntToStr(i));
		}
		return ret;
	}
	
}
