package view;

import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import testThings.NonDeterministicTest;
import testThings.NonDeterministicTestComparer;
import testThings.Test;
import testThings.TestComparer;

public class TestingScreen extends Group{
	private TextArea inputs;
	private Spinner<Integer> mutants;
	private Spinner<Integer> typeOfMutation;
	private Spinner<Double> prob;
	private TextArea matrix;
	private GridPane gp;
	private Button add;
	private Button rem;
	private Button comp;
	private Button randTest;
	private Button allTest;
	private Button cancel;
	private Container c;
	private Stage st;
	private Text t1;
	private Text t2;
	private Text t3;
	private ListView<TestView> inps;
	
	public TestingScreen(Stage sta,Container co){
		this.st=sta;
		this.c=co;
		this.t1=new Text("Introduce inputs here");
		this.t2=new Text("Number of mutants               ");
		this.t3=new Text("0-mutate outputs,1-destinies \n2-Extra state");
		this.inputs=new TextArea();
		inputs.setMaxWidth(400);
		inputs.setMaxHeight(20);
		this.inputs.setMaxHeight(20);
		this.mutants=new Spinner<Integer>(new SpinnerValueFactory.
				IntegerSpinnerValueFactory(1, 1000, 1000));
		this.prob=new Spinner<Double>(new SpinnerValueFactory.
				DoubleSpinnerValueFactory(0, 1,0.7, 0.05));
		this.typeOfMutation=new Spinner<Integer>(new SpinnerValueFactory.
				IntegerSpinnerValueFactory(0, 2, 0));
		this.typeOfMutation.valueProperty().addListener((obs, oldValue, newValue) -> 
	    	{
	    		if(newValue==2) {
	    			prob.setManaged(true);
	    			prob.setVisible(true);
	    		}
	    		else {
	    			prob.setManaged(false);
	    			prob.setVisible(false);
	    		}
	    	});
		this.matrix=new TextArea();
		matrix.setMinHeight(150);
		matrix.setMaxHeight(150);
		matrix.setMinWidth(300);
		matrix.setMaxWidth(300);
		this.add=new Button("Add test");
		this.rem=new Button("Remove test");
		this.comp=new Button("Realizar comparacion");
		this.randTest=new Button("Add random test");
		this.cancel=new Button("Cancelar");
		this.allTest=new Button("Add all tests of lon k");
		this.inps=new ListView<TestView>();
		this.add.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent arg0) {
				// TODO Auto-generated method stub
				String [] aux=inputs.getText().split(" ");
				ArrayList<String> in=new ArrayList<String>();
				for(int i=0;i<aux.length;i++){
					in.add(aux[i]);
				}
				inps.getItems().add(new TestView(in));
				}
		});
		this.rem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(final ActionEvent e) {
            	int selectedIdx = inps.getSelectionModel().getSelectedIndex();
                if(selectedIdx!=-1){
                	
                	 final int newSelectedIdx =
                             (selectedIdx == inps.getItems().size() - 1)
                                     ? selectedIdx - 1
                                     : selectedIdx;
                	
                	 inps.getItems().remove(selectedIdx);
                	 inps.getSelectionModel().select(newSelectedIdx);
                     //removes the player for the array
                }
            }});
		this.comp.setOnAction(
	            new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) {
	                		NonDeterministicTestComparer comp=
	                				new NonDeterministicTestComparer(c.getMm(),typeOfMutation.getValue(),
	                				mutants.getValue(), prob.getValue());
	                		ArrayList<String> caso;
	                		ArrayList<Integer> aux;
	                		NonDeterministicTest te;
	                		for(int i=0;i<inps.getItems().size();i++){
		                		aux=new ArrayList<Integer>();
	                			caso=inps.getItems().get(i).getInputs();
	                			/*for(int j=0;j<caso.size();j++){
	                				//aux.add(c.translateIn(caso.get(i)));
	                			}*/
	                			//System.out.println(caso.toString());
	                			te=new NonDeterministicTest(caso,c.getMm());
	                			comp.addTest(te);
	                			TestView viewActual=inps.getItems().get(i);
	                			inps.getItems().get(i).outputs=te.getOutputs();
	                			inps.getItems().get(i).setOnMouseClicked((eee)-> {
										 final Stage dialog = new Stage();
							              dialog.initModality(Modality.APPLICATION_MODAL);
							              dialog.initOwner(sta);
							              Text t=new Text(viewActual.outputs.toString());
							              HBox dialogHBox=new HBox(20);
							              dialogHBox.getChildren().add(t);
							              Scene dialogScene = new Scene(dialogHBox, 300, 200);
							              dialog.setScene(dialogScene);
							              dialog.show();
	                				});
	                			//comp.addTestTester(te);
	                		}
	                		c.setTc(comp);
	                		c.getTc().runAll();
	                		/*StringBuilder sb=new StringBuilder();
	                		for(int i=0;i<c.getTc().size();i++){
	                			sb.append(c.getTc().getOutput(i));
	                			sb.append("\n");
	                		}
	                		outputs.setText(sb.toString());*/
	                		matrix.setText(c.getTc().getMatrix());
	                }
	            });
		
		this.allTest.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
                final Stage dialog = new Stage();
                dialog.initModality(Modality.APPLICATION_MODAL);
                dialog.initOwner(sta);
                HBox dialogHBox=new HBox(20);
        		Spinner<Integer> lenOfTest=new Spinner<Integer>(new SpinnerValueFactory.
        				IntegerSpinnerValueFactory(1, 30, 5));
        		Button add=new Button("Add tests");
        		add.setOnAction(new EventHandler<ActionEvent>(){
					@Override
					public void handle(ActionEvent arg0) {
						int lon=lenOfTest.getValue();
						ArrayList<ArrayList<String>> inpss=
								c.generateTestsOfLen(lon);
						for(int i=0;i<inpss.size();i++) {
							inps.getItems().add(new TestView(inpss.get(i)));
						}
						
						dialog.close();
					}
        		});
        		dialogHBox.getChildren().add(add);
        		dialogHBox.getChildren().add(lenOfTest);
        		Scene dialogScene = new Scene(dialogHBox, 300, 200);
                dialog.setScene(dialogScene);
                dialog.show();
			}
		});
		
		this.randTest.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
                final Stage dialog = new Stage();
                dialog.initModality(Modality.APPLICATION_MODAL);
                dialog.initOwner(sta);
                HBox dialogHBox=new HBox(20);
        		Spinner<Integer> sizeOfTest=new Spinner<Integer>(new SpinnerValueFactory.
        				IntegerSpinnerValueFactory(1, 30, 6));
        		Button add=new Button("Add test");
        		add.setOnAction(new EventHandler<ActionEvent>(){
					@Override
					public void handle(ActionEvent arg0) {
						int lon=sizeOfTest.getValue();
						inps.getItems().add(new TestView(
								c.generateRandomTest(sizeOfTest.getValue())));
						dialog.close();
					}
        		});
        		dialogHBox.getChildren().add(add);
        		dialogHBox.getChildren().add(sizeOfTest);
        		Scene dialogScene = new Scene(dialogHBox, 300, 200);
                dialog.setScene(dialogScene);
                dialog.show();
			}
			
		});
		this.cancel.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				Scene sc=new Scene(new FirstScreen(st,c));
        		sta.setScene(sc);
        		sta.show();
			}
			
		});
		/*this.b2.setOnAction(
	            new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) { 
	                	String texto="";
	                	File file = fc.showOpenDialog(st);
	                	if (file != null) {
                        //openFile(file);
	                		texto=readFile(file);
	                	}
	                	inputs.setText(texto);
	                }
	            });*/
		Text aux=new Text("Write input");
		this.gp=new GridPane();
		this.inps.setMaxHeight(200);
		
		HBox h1=new HBox();
		h1.getChildren().add(t2);
		h1.getChildren().add(mutants);

		HBox h2=new HBox();
		h2.getChildren().add(t3);
		h2.getChildren().add(typeOfMutation);
		h2.getChildren().add(prob);
		prob.setManaged(false);
		prob.setVisible(false);
		
		HBox h3=new HBox();
		h3.setSpacing(15);
		HBox.setMargin(aux, new Insets(50,10,10,10));
		h3.getChildren().add(aux);
		HBox h4=new HBox();
		h4.setSpacing(10);
		inputs.setMaxHeight(25);
		inputs.setMinHeight(25);
		inputs.setMaxWidth(150);
		inputs.setMinWidth(150);
		h4.getChildren().add(inputs);
		h4.getChildren().add(add);
		VBox v1=new VBox();
		VBox.setMargin(rem, new Insets(10,10,10,10));
		VBox.setMargin(h4, new Insets(20,20,20,20));
		v1.setSpacing(20);
		v1.getChildren().add(h4);
		v1.getChildren().add(randTest);
		v1.getChildren().add(allTest);
		VBox.setMargin(rem, new Insets(0,0,0,30));
		v1.getChildren().add(rem);

		h3.getChildren().add(v1);
		h3.getChildren().add(inps);
		StackPane sp1=new StackPane();
		sp1.getChildren().add(h3);
		sp1.setBorder(new Border(new BorderStroke(Color.LIGHTGREY, 
	            BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
		
		Text aux2=new Text("Comparation matrix");
		
		HBox h5=new HBox();
		h5.getChildren().add(aux2);
		h5.getChildren().add(matrix);
		h5.setSpacing(10);
		
		VBox v2=new VBox();
		VBox.setMargin(h1, new Insets(10,10,10,10));
		VBox.setMargin(h2, new Insets(10,10,10,10));
		VBox.setMargin(sp1, new Insets(10,10,10,10));
		VBox.setMargin(comp, new Insets(10,10,10,10));
		VBox.setMargin(h5, new Insets(10,10,10,10));
		v2.setSpacing(5);
		v2.getChildren().add(h1);
		v2.getChildren().add(h2);
		v2.getChildren().add(sp1);
		v2.getChildren().add(comp);
		v2.getChildren().add(h5);
		v2.getChildren().add(cancel);
		/*gp.add(t2, 0, 0);
		gp.add(mutants, 1, 0);
		gp.add(t3, 0, 1);
		gp.add(typeOfMutation, 1, 1);
		gp.add(add, 0, 2);
		gp.add(randTest, 2, 2);
		gp.add(inputs, 1, 2);
		gp.add(inps, 0,3);
		gp.add(rem,1,3);
		gp.add(comp, 0, 4);
		gp.add(new Text("Comparation \n Matrix"), 0, 5);
		gp.add(this.matrix, 1, 5);
		*/
		this.getChildren().add(v2);
	}

	private class TestView extends Group{
		public ArrayList<String> inputs;
		public ArrayList<ArrayList<String>> outputs;
		public GridPane gp;
		
		public TestView(ArrayList<String> in) {
			this.inputs=in;
			this.gp=new GridPane();
			this.gp.setMaxHeight(15);
			this.gp.setHgap(10);
			for(int i=0;i<in.size();i++){
				gp.add(new Text(in.get(i)), i, 0);
			}
			this.getChildren().add(gp);
		}
		
		public ArrayList<String> getInputs(){
			return inputs;
		}
		
		public String get(int i){
			return inputs.get(i);
		}
	}
	
}
