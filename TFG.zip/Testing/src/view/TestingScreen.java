package view;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import mealyMachine.MealyMachine;
import testThings.NonDeterministicTest;
import testThings.NonDeterministicTestComparer;

public class TestingScreen extends Group{
	private TextArea inputs;
	private Spinner<Integer> mutants;
	private Spinner<Integer> typeOfMutation;
	private Spinner<Double> prob;
	private TextArea matrix;
	private TextArea perc;
	private TextArea resil;
	private GridPane gp;
	private Button add;
	private Button rem;
	private Button comp;
	private Button randTest;
	private Button allTest;
	private Button cancel;
	private Button reset;
	private Container c;
	private Stage st;
	private Text t1;
	private Text t2;
	private Text t3;
	private ListView<TestView> inps;
	private ListView<Text> muts;
	private MenuBar menu;
	CheckBox allMutants;
	private Button addMut;
	private Button removeMut;
	private Button resetMuts;
	private HBox mutPart;
	
	public TestingScreen(Stage sta,Container co){
		this.st=sta;
		this.c=co;
		this.t1=new Text("Introduce inputs here");
		this.t2=new Text("Number of mutants               ");
		this.t3=new Text("0-mutate outputs,1-destinies \n2-Extra state");
		this.inputs=new TextArea();
		this.allMutants = 
				new CheckBox("Generate all mutants, only valid for mutation of type 0 and 1");
		inputs.setMaxWidth(400);
		inputs.setMaxHeight(20);
		this.inputs.setMaxHeight(20);
		this.mutants=new Spinner<Integer>(new SpinnerValueFactory.
				IntegerSpinnerValueFactory(0, 1000, 50));
		mutants.setEditable(true);
		mutants.focusedProperty().addListener((observable, oldValue, newValue) -> {
			  if (!newValue) {
				    mutants.increment(0); // won't change value, but will commit editor
				  }
				});
		this.prob=new Spinner<Double>(new SpinnerValueFactory.
				DoubleSpinnerValueFactory(0, 1,0.7, 0.05));
		this.typeOfMutation=new Spinner<Integer>(new SpinnerValueFactory.
				IntegerSpinnerValueFactory(0, 2, 0));
		this.typeOfMutation.valueProperty().addListener((obs, oldValue, newValue) -> 
	    	{
	    		if(newValue==2) {
	    			prob.setManaged(true);
	    			prob.setVisible(true);
	    		}
	    		else {
	    			prob.setManaged(false);
	    			prob.setVisible(false);
	    		}
	    	});
		this.matrix=new TextArea();
		matrix.setMinHeight(125);
		matrix.setMaxHeight(125);
		matrix.setMinWidth(300);
		matrix.setMaxWidth(300);
		this.perc=new TextArea();
		perc.setMinHeight(125);
		perc.setMaxHeight(125);
		perc.setMinWidth(100);
		perc.setMaxWidth(100);
		this.resil=new TextArea();
		resil.setMinHeight(125);
		resil.setMaxHeight(125);
		resil.setMinWidth(100);
		resil.setMaxWidth(100);
		this.add=new Button("Add test");
		this.rem=new Button("Remove test");
		this.comp=new Button("Compare tests");
		this.randTest=new Button("Add random test");
		this.cancel=new Button("Back");
		this.allTest=new Button("Add all tests of lon k");
		this.reset=new Button("Reset inputs");
		this.inps=new ListView<TestView>();
		this.add.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent arg0) {
				// TODO Auto-generated method stub
				String [] aux=inputs.getText().split(" ");
				ArrayList<String> in=new ArrayList<String>();
				for(int i=0;i<aux.length;i++){
					in.add(aux[i]);
				}
				inps.getItems().add(new TestView(in));
			}
		});
		this.rem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(final ActionEvent e) {
            	int selectedIdx = inps.getSelectionModel().getSelectedIndex();
                if(selectedIdx!=-1){
                	
                	 final int newSelectedIdx =
                             (selectedIdx == inps.getItems().size() - 1)
                                     ? selectedIdx - 1
                                     : selectedIdx;
                	
                	 inps.getItems().remove(selectedIdx);
                	 inps.getSelectionModel().select(newSelectedIdx);
                     //removes the player for the array
                }
            }});
		this.reset.setOnAction(
				new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) {
	                	inps.getItems().clear();
	                }
				});
		
		this.comp.setOnAction(
	            new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) {
	                	NonDeterministicTestComparer comp;
                		String path;
                		MealyMachine casom;
	                	if(typeOfMutation.getValue()!=2 && allMutants.isSelected()) {
	                		comp= new NonDeterministicTestComparer
	    	                		(c.getMm(), typeOfMutation.getValue());
	                	}
	                	else{
	                		comp= new NonDeterministicTestComparer
	    	                		(c.getMm(),typeOfMutation.getValue(),
	    	                				mutants.getValue(), prob.getValue());
	                		ArrayList<MealyMachine> mutants;
	                		for(int i=0;i<muts.getItems().size();i++) {
	                			mutants=new ArrayList<MealyMachine>();
	                			path=muts.getItems().get(i).getText();
	                			File f = new File(path);
	                			try {
	                				BufferedReader br = new BufferedReader(new FileReader(f)); 
	                				String str; 
	                				String[] str1; 
	                				str=br.readLine();
	                				if(Integer.parseInt(str)<2) {
	                					while ((str = br.readLine()) != null) {
	                						if(!str.equals("")) {
	                						str1=str.split(" ");
	                						casom=c.getMm().applyMutation(
	                								Integer.parseInt(str1[0]), 
	                								Integer.parseInt(str1[1]), 
	                								Integer.parseInt(str1[2]), 
	                								Integer.parseInt(str1[3]));
	                						mutants.add(casom);
	                						}
		                				}
	                				}else {
	                					StringBuilder sb=new StringBuilder();
	                					while ((str = br.readLine()) != null) {
	                						sb.append(str);
	                						sb.append("\n");
		                				}
	                					str1=str.split("###");
	                					for(int k=0;k<str1.length;k++) {
	                						try {
												mutants.add(new MealyMachine(str1[k]));
											} catch (Exception e1) {
				                				ErrorDialog err=new ErrorDialog("Could not parse mutant in file "+path,st);
				                				err.show();
											}
	                					}
	                				}
	                				br.close();
	                			} catch (IOException e2) {
	                				ErrorDialog err=new ErrorDialog("Could not open file "+path,st);
	                				err.show();
	                			} 
	                			comp.addMutants(mutants);
	                		}
	                	}
	                	ArrayList<String> caso;
	                	ArrayList<Integer> aux;
	                	NonDeterministicTest te;
	                	for(int i=0; i<inps.getItems().size(); i++){
	                		aux=new ArrayList<Integer>();
	                		caso=inps.getItems().get(i).getInputs();
	                		/*for(int j=0;j<caso.size();j++){
	                				//aux.add(c.translateIn(caso.get(i)));
	                			}*/
	                		//System.out.println(caso.toString());
	                		te=new NonDeterministicTest(caso,c.getMm());
	                		comp.addTest(te);
	                		TestView viewActual=inps.getItems().get(i);
	                		inps.getItems().get(i).outputs=te.getOutputs();
	                		inps.getItems().get(i).setOnMouseClicked((eee)-> {
	                			final Stage dialog = new Stage();
	                			dialog.initModality(Modality.APPLICATION_MODAL);
	                			dialog.initOwner(sta);
	                			Text t=new Text(viewActual.outputs.toString());
	                			HBox dialogHBox=new HBox(20);
	                			dialogHBox.getChildren().add(t);
	                			Scene dialogScene = new Scene(dialogHBox, 300, 200);
	                			dialog.setScene(dialogScene);
	                			dialog.show();
	                		});
	                		//comp.addTestTester(te);
	                	}
	                	c.setTc(comp);
	                	c.getTc().runAll();
	                	/*StringBuilder sb=new StringBuilder();
	                		for(int i=0;i<c.getTc().size();i++){
	                			sb.append(c.getTc().getOutput(i));
	                			sb.append("\n");
	                		}
	                		outputs.setText(sb.toString());*/
	                	matrix.setText(c.getTc().getMatrix());
	                	perc.setText(c.getTc().getPerc());
	                	resil.setText(c.getTc().mutScore());
	                }
	            });

		this.allTest.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				final Stage dialog = new Stage();
				dialog.initModality(Modality.APPLICATION_MODAL);
				dialog.initOwner(sta);
                HBox dialogHBox=new HBox(20);
        		Spinner<Integer> lenOfTest=new Spinner<Integer>(new SpinnerValueFactory.
        				IntegerSpinnerValueFactory(1, 30, 5));
        		Button add=new Button("Add tests");
        		add.setOnAction(new EventHandler<ActionEvent>(){
					@Override
					public void handle(ActionEvent arg0) {
						int lon=lenOfTest.getValue();
						ArrayList<ArrayList<String>> inpss=
								c.generateTestsOfLen(lon);
						for(int i=0;i<inpss.size();i++) {
							inps.getItems().add(new TestView(inpss.get(i)));
						}
						
						dialog.close();
					}
        		});
        		dialogHBox.getChildren().add(add);
        		dialogHBox.getChildren().add(lenOfTest);
        		Scene dialogScene = new Scene(dialogHBox, 300, 200);
                dialog.setScene(dialogScene);
                dialog.show();
			}
		});
		
		this.randTest.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
                final Stage dialog = new Stage();
                dialog.initModality(Modality.APPLICATION_MODAL);
                dialog.initOwner(sta);
                VBox dialogVBox=new VBox(20);
                HBox hbox1=new HBox();
                HBox hbox2=new HBox();
        		Spinner<Integer> sizeOfTest=new Spinner<Integer>(new SpinnerValueFactory.
        				IntegerSpinnerValueFactory(1, 1000, 10));
        		Spinner<Integer> numberOfTests=new Spinner<Integer>(new SpinnerValueFactory.
        				IntegerSpinnerValueFactory(1, 10000, 1));
        		numberOfTests.setEditable(true);
        		sizeOfTest.setEditable(true);
        		sizeOfTest.focusedProperty().addListener((observable, oldValue, newValue) -> {
    				  if (!newValue) {
    					  sizeOfTest.increment(0); // won't change value, but will commit editor
    					  }
    					});
        		numberOfTests.focusedProperty().addListener((observable, oldValue, newValue) -> {
    				  if (!newValue) {
    					  numberOfTests.increment(0); // won't change value, but will commit editor
    					  }
    					});
        		Button add=new Button("Add test");
        		add.setOnAction(new EventHandler<ActionEvent>(){
					@Override
					public void handle(ActionEvent arg0) {
						int lon=sizeOfTest.getValue();
						for(int i=0;i<numberOfTests.getValue();i++) {
						inps.getItems().add(new TestView(
								c.generateRandomTest(lon)));
						}
						dialog.close();
					}
        		});
        		hbox1.setSpacing(5);
        		hbox2.setSpacing(5);
        		dialogVBox.setSpacing(5);
                hbox1.getChildren().add(new Text("Number of test cases"));
                hbox1.getChildren().add(numberOfTests);
                hbox2.getChildren().add(new Text("Length of the tests"));
                hbox2.getChildren().add(sizeOfTest);
        		dialogVBox.getChildren().add(hbox1);
        		dialogVBox.getChildren().add(hbox2);
        		dialogVBox.getChildren().add(add);
        		Scene dialogScene = new Scene(dialogVBox, 300, 200);
                dialog.setScene(dialogScene);
                dialog.show();
			}
			
		});
		this.cancel.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent arg0) {
				Scene sc=new Scene(new FirstScreen(st,c));
        		sta.setScene(sc);
        		sta.show();
			}
			
		});
		/*this.b2.setOnAction(
	            new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) { 
	                	String texto="";
	                	File file = fc.showOpenDialog(st);
	                	if (file != null) {
                        //openFile(file);
	                		texto=readFile(file);
	                	}
	                	inputs.setText(texto);
	                }
	            });*/
		this.setMenu();
		this.setMutPart();
		Text aux=new Text("Write input");
		this.gp=new GridPane();
		this.inps.setMaxHeight(120);
		this.inps.setMaxHeight(120);
		HBox.setMargin(inps, new Insets(10,5,10,5));
		HBox h1=new HBox();
		h1.setSpacing(10);
		h1.getChildren().add(t2);
		h1.getChildren().add(mutants);
		h1.getChildren().add(allMutants);
		HBox h2=new HBox();
		h2.getChildren().add(t3);
		h2.getChildren().add(typeOfMutation);
		h2.getChildren().add(prob);
		prob.setManaged(false);
		prob.setVisible(false);
		
		HBox h3=new HBox();
		h3.setSpacing(15);
		HBox h4=new HBox();
		h4.setSpacing(10);
		inputs.setMaxHeight(25);
		inputs.setMinHeight(25);
		inputs.setMaxWidth(150);
		inputs.setMinWidth(150);
		h4.getChildren().add(aux);
		h4.getChildren().add(inputs);
		h4.getChildren().add(add);
		VBox v1=new VBox();
		VBox.setMargin(h4, new Insets(10,5,10,5));
		v1.setSpacing(10);
		v1.getChildren().add(h4);
		HBox hbox1=new HBox();
		hbox1.setSpacing(5);
		hbox1.getChildren().add(randTest);
		hbox1.getChildren().add(allTest);
		HBox hbox2=new HBox();
		hbox2.setSpacing(5);
		hbox2.getChildren().add(rem);
		hbox2.getChildren().add(reset);
		v1.getChildren().add(hbox1);
		v1.getChildren().add(hbox2);
		VBox.setMargin(hbox1, new Insets(5,10,5,10));
		VBox.setMargin(hbox2, new Insets(5,10,5,10));
		//VBox.setMargin(rem, new Insets(0,0,0,30));

		h3.getChildren().add(v1);
		HBox.setMargin(h3, new Insets(10,0,10,0));
		h3.getChildren().add(inps);
		StackPane sp1=new StackPane();
		sp1.getChildren().add(h3);
		sp1.setBorder(new Border(new BorderStroke(Color.LIGHTGREY, 
	            BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
		
		Text aux2=new Text("Comparation matrix");
		Text aux3=new Text("% of killed mutants");
		Text aux4=new Text("Top resilient mutants(%tests they survived)");
		HBox h5=new HBox();
		VBox vaux1=new VBox();
		vaux1.getChildren().add(aux2);
		vaux1.getChildren().add(matrix);
		VBox vaux2=new VBox();
		vaux2.getChildren().add(aux3);
		vaux2.getChildren().add(perc);
		VBox vaux3=new VBox();
		vaux3.getChildren().add(aux4);
		vaux3.getChildren().add(resil);
		h5.getChildren().add(vaux1);
		h5.getChildren().add(vaux2);
		h5.getChildren().add(vaux3);
		h5.setSpacing(10);
		
		VBox v2=new VBox();
		VBox.setMargin(h1, new Insets(3,10,3,10));
		VBox.setMargin(h2, new Insets(3,10,3,10));
		VBox.setMargin(sp1, new Insets(3,0,3,0));
		VBox.setMargin(comp, new Insets(10,10,2,10));
		VBox.setMargin(h5, new Insets(3,10,3,10));
		v2.setSpacing(2);
		v2.getChildren().add(menu);
		v2.getChildren().add(h1);
		v2.getChildren().add(h2);
		v2.getChildren().add(sp1);
		v2.getChildren().add(mutPart);
		v2.getChildren().add(comp);
		v2.getChildren().add(h5);
		v2.getChildren().add(cancel);
		VBox.setMargin(cancel, new Insets(0,10,0,10));
		/*gp.add(t2, 0, 0);
		gp.add(mutants, 1, 0);
		gp.add(t3, 0, 1);
		gp.add(typeOfMutation, 1, 1);
		gp.add(add, 0, 2);
		gp.add(randTest, 2, 2);
		gp.add(inputs, 1, 2);
		gp.add(inps, 0,3);
		gp.add(rem,1,3);
		gp.add(comp, 0, 4);
		gp.add(new Text("Comparation \n Matrix"), 0, 5);
		gp.add(this.matrix, 1, 5);
		*/
		this.getChildren().add(v2);
	}

	public void setMenu() {
		menu=new MenuBar();
		Menu opt1=new Menu("File");
		MenuItem loadInputFile=new MenuItem("Load inputs file");
		MenuItem saveBestInputs= new MenuItem("Save best testing cases");
		MenuItem loadMutants=new MenuItem("Load mutants file");
		MenuItem saveBestMutants= new MenuItem("Save most resilient mutants");

		loadInputFile.setOnAction(
				new EventHandler<ActionEvent>() {
					@Override
					public void handle(final ActionEvent e) { 
						FileChooser fc=new FileChooser();
						File file = fc.showOpenDialog(st);
						if (file != null) {
							//openFile(file);
							try {
								BufferedReader br = new BufferedReader(new FileReader(file)); 
								String str; 
								while ((str = br.readLine()) != null) {
									if(!str.contentEquals("")) {
										inps.getItems().add(new TestView(
											new ArrayList<String>(
													Arrays.asList(str.split(" ")))));
									}
								}
								br.close();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} 
						}
						
					}
				});
		saveBestInputs.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				final Stage dialog = new Stage();
    			dialog.initModality(Modality.APPLICATION_MODAL);
    			dialog.initOwner(st);
    			Button save=new Button("Save");
    			Spinner<Integer> topX=new Spinner<Integer>(new SpinnerValueFactory.
    					IntegerSpinnerValueFactory(1, 10000, 10));
    			topX.focusedProperty().addListener((observable, oldValue, newValue) -> {
    				  if (!newValue) {
    					    topX.increment(0); // won't change value, but will commit editor
    					  }
    					});
    			topX.setEditable(true);
    			save.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent arg0) {
						FileChooser fc=new FileChooser();
						FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
						fc.getExtensionFilters().add(extFilter);
						File file = fc.showSaveDialog(dialog);
						if (file != null) {
							try {
								PrintWriter writer;
								writer = new PrintWriter(file);
								if(c.getTc()==null) {
									ErrorDialog err=new ErrorDialog("You need to compare in order to see "
											+ "\n what test cases are good.", st);
									err.show();
								}else {
									writer.println(c.getTc().topInputs(topX.getValue()));
									writer.close();
								}
							} catch (IOException ex) {
								ErrorDialog err=new ErrorDialog("File could not be saved", st);
								err.show();
							}
						}
						dialog.close();
					}
    			});
    			VBox dialogVBox=new VBox(20);
    			dialogVBox.getChildren().add(topX);
    			dialogVBox.getChildren().add(save);
    			Scene dialogScene = new Scene(dialogVBox, 300, 200);
    			dialog.setScene(dialogScene);
    			dialog.show();
			}
		});
		
		saveBestMutants.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {

				final Stage dialog = new Stage();
    			dialog.initModality(Modality.APPLICATION_MODAL);
    			dialog.initOwner(st);
    			Button save=new Button("Save");
    			Spinner<Integer> topX=new Spinner<Integer>(new SpinnerValueFactory.
    					IntegerSpinnerValueFactory(1, 10000, 10));
    			topX.focusedProperty().addListener((observable, oldValue, newValue) -> {
    				  if (!newValue) {
    					    topX.increment(0); // won't change value, but will commit editor
    					  }
    					});
    			topX.setEditable(true);
    			save.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent arg0) {
						FileChooser fc=new FileChooser();
						FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
						fc.getExtensionFilters().add(extFilter);
						File file = fc.showSaveDialog(dialog);
						if (file != null) {
							try {
								PrintWriter writer;
								writer = new PrintWriter(file);
								writer.println(typeOfMutation.getValue());
								writer.println(c.getTc().topMutants(topX.getValue()));
								writer.close();
							} catch (IOException ex) {
								ErrorDialog err=new ErrorDialog("File could not be saved", st);
								err.show();
							}
						}
						dialog.close();
					}
    			});
    			VBox dialogVBox=new VBox(20);
    			dialogVBox.getChildren().add(topX);
    			dialogVBox.getChildren().add(save);
    			Scene dialogScene = new Scene(dialogVBox, 300, 200);
    			dialog.setScene(dialogScene);
    			dialog.show();
			}
		});
		loadMutants.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				FileChooser fc=new FileChooser();
				File file = fc.showOpenDialog(st);
				if (file != null) {
					muts.getItems().add(new Text(file.getPath()));
					} 
				}
		});

		opt1.getItems().add(saveBestInputs);
		opt1.getItems().add(loadInputFile);
		opt1.getItems().add(loadMutants);
		opt1.getItems().add(saveBestMutants);
		
		menu.getMenus().add(opt1);
		menu.prefWidthProperty().bind(st.widthProperty());
	}
	
	public void setMutPart() {
		this.addMut=new Button("Add mutant set");
		this.removeMut=new Button("Remove mutant set");
		this.resetMuts=new Button("Reset mutants");
		this.muts=new ListView<Text>();
		muts.setMaxHeight(100);
		muts.setMinHeight(100);
		addMut.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				FileChooser fc=new FileChooser();
				File file = fc.showOpenDialog(st);
				if (file != null) {
					muts.getItems().add(new Text(file.getPath()));
				}
			}
		});
		removeMut.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				int selectedIdx = muts.getSelectionModel().getSelectedIndex();
                if(selectedIdx!=-1){
                	
                	 final int newSelectedIdx =
                             (selectedIdx == muts.getItems().size() - 1)
                                     ? selectedIdx - 1
                                     : selectedIdx;
                	
                	 muts.getItems().remove(selectedIdx);
                	 muts.getSelectionModel().select(newSelectedIdx);
                     //removes the player for the array
                }
			}
		});
		resetMuts.setOnAction(new EventHandler<ActionEvent>() {
			 @Override
             public void handle(final ActionEvent e) {
             	muts.getItems().clear();
             }
		});
		mutPart=new HBox();
		VBox aux=new VBox();
		HBox.setMargin(aux, new Insets(5,5,5,10));
		mutPart.setSpacing(3);
		aux.setSpacing(3);
		aux.getChildren().add(addMut);
		aux.getChildren().add(removeMut);
		aux.getChildren().add(resetMuts);
		mutPart.getChildren().add(aux);
		mutPart.getChildren().add(muts);
	}
	
	private class TestView extends Group{
		public ArrayList<String> inputs;
		public ArrayList<ArrayList<String>> outputs;
		public GridPane gp;
		
		public TestView(ArrayList<String> in) {
			this.inputs=in;
			this.gp=new GridPane();
			this.gp.setMaxHeight(15);
			this.gp.setHgap(10);
			for(int i=0;i<in.size();i++){
				gp.add(new Text(in.get(i)), i, 0);
			}
			this.getChildren().add(gp);
		}
		
		public ArrayList<String> getInputs(){
			return inputs;
		}
		
		public String get(int i){
			return inputs.get(i);
		}
	}
	
}
