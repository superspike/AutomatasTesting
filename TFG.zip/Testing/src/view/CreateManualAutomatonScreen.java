package view;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import mealyMachine.MealyMachine;

public class CreateManualAutomatonScreen extends MealyCreatorGroup {

	private Container c;
	private Stage st;
	private Button add;
	private Button rem;
	private Button b1;
	private int numStates;
	private int inAlphSize;
	private int outAlphSize;
	private GridPane gp;
	private ArrayList<Integer> stateList;
	private ArrayList<String> outputsList;
	private ArrayList<String> inputsList;
	private ComboBox<String> cin;
	private ComboBox<String> cout;
	private ComboBox<Integer> cst1;
	private ComboBox<Integer> cst2;
	private ListView<TransitionView> table;
	
	public CreateManualAutomatonScreen(int numStates, ArrayList<String> in, ArrayList<String> out, Stage sta, Container co){
		this.add=new Button("Add");
		this.rem=new Button("Remove");
		this.st=sta;
		this.numStates=numStates;
		this.inAlphSize=in.size();
		this.outAlphSize = out.size();
		this.c=co;
		table=new ListView<TransitionView>();
		b1=new Button("Generate automaton");
		//b2=new Button("Begin test");
		this.gp=new GridPane();
		this.outputsList=out;
		this.inputsList=in;
		this.stateList=new ArrayList<Integer>();
		for(int i=0;i<numStates;i++){
			stateList.add(i);
		}
		this.cin=new ComboBox<String>(FXCollections.observableArrayList(in));
		this.cout=new ComboBox<String>(FXCollections.observableArrayList(out));
		this.cst1=new ComboBox<Integer>(FXCollections.observableArrayList(stateList));
		this.cst2=new ComboBox<Integer>(FXCollections.observableArrayList(stateList));
		add.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(final ActionEvent e) {
            	table.getItems().add(new TransitionView(
            			Integer.parseInt(cst1.getSelectionModel().getSelectedItem().toString()),
            			Integer.parseInt(cst2.getSelectionModel().getSelectedItem().toString()),
            			cin.getSelectionModel().getSelectedItem().toString(),
            			cout.getSelectionModel().getSelectedItem().toString()
            			));
            }});
		rem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(final ActionEvent e) {
            	int selectedIdx = table.getSelectionModel().getSelectedIndex();
                if(selectedIdx!=-1){
                	
                	 final int newSelectedIdx =
                             (selectedIdx == table.getItems().size() - 1)
                                     ? selectedIdx - 1
                                     : selectedIdx;
                	
                	 table.getItems().remove(selectedIdx);
                	 table.getSelectionModel().select(newSelectedIdx);
                     //removes the player for the array
                }
            }});
		b1.setOnAction(
	            new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(final ActionEvent e) {
	                		MealyMachine mod=new MealyMachine(numStates,in, out, false,0);
	                		ArrayList<TransitionView> aux=new ArrayList<TransitionView>(table.getItems());
	                		for(int i=0;i<table.getItems().size();i++){
	                			mod.addTransition(aux.get(i).getS0(),
	                					aux.get(i).getS1(),
	                					aux.get(i).getIn(),
	                					aux.get(i).getOut());
	                		}
	                		c.setMm(mod);
	                		c.setFs(new FirstScreen(sta,c));
	                		Scene sc=new Scene(c.getFs(),800,600);
	                		st.setScene(sc);
	                		c.changeText();
	                    }
	            });

		add.setMinHeight(25);
		add.setMaxHeight(25);
		add.setMinWidth(120);
		add.setMaxWidth(120);
		
		Text t1=new Text("Initial state");
		Text t2=new Text("Final state  ");
		Text t3=new Text("Input         ");
		Text t4=new Text("Output       ");
		
		
		HBox h1=new HBox();
		h1.setSpacing(5);
		h1.getChildren().add(t1);
		h1.getChildren().add(cst1);
		HBox h2=new HBox();
		h2.setSpacing(5);
		h2.getChildren().add(t2);
		h2.getChildren().add(cst2);
		HBox h3=new HBox();
		h3.setSpacing(5);
		h3.getChildren().add(t3);
		h3.getChildren().add(cin);
		HBox h4=new HBox();
		h4.setSpacing(5);
		h4.getChildren().add(t4);
		h4.getChildren().add(cout);
		
		VBox v1=new VBox();
		v1.setSpacing(6);
		v1.getChildren().add(h1);
		v1.getChildren().add(h2);
		v1.getChildren().add(h3);
		v1.getChildren().add(h4);
		v1.getChildren().add(add);
		
		HBox h5=new HBox();
		h5.setSpacing(10);
		h5.getChildren().add(v1);
		h5.getChildren().add(table);
		h5.getChildren().add(rem);
		
		VBox v2=new VBox();
		v2.getChildren().add(h5);
		v2.getChildren().add(b1);
		
		this.getChildren().add(v2);
	}
	
	public MealyMachine getMealyMachine(){
		return c.getMm();
	}
	
	private class TransitionView extends Group{
		
		private Integer s0;
		private Integer s1;
		private String in;
		private String out;
		
		public TransitionView(Integer s, Integer t, String in, String out){
			super();
			s0=s;
			s1=t;
			this.in=in;
			this.out=out;
			gp=new GridPane();
			gp.add(new Text(s.toString()),0,0);
			gp.add(new Text(t.toString()),1,0);
			gp.add(new Text(in),2,0);
			gp.add(new Text(out),3,0);
			gp.setHgap(20);
			this.getChildren().add(gp);
		}
		public Integer getS0() {return s0;}
		public void setS0(Integer s0) {this.s0 = s0;}
		public Integer getS1() {return s1;}
		public void setS1(Integer s1) {this.s1 = s1;}
		public String getIn() {return in;}
		public void setIn(String in) {this.in = in;}
		public String getOut() {return out;}
		public void setOut(String out) {this.out = out;}
	}
	
}
