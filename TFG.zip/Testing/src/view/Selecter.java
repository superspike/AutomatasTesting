package view;

import java.io.File;

import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.Window;

public class Selecter {
	public FileChooser fc;
	public Window w;
	public static FileChooser createFileChooser(){
		return new FileChooser();
	}
	public Selecter(Window parent) {
		w=parent;
		fc=Selecter.createFileChooser();
	}
	public static void main(String args[]) {
		FileChooser fl = new FileChooser();
	}
}
