package testThings;

import java.util.ArrayList;

import mealyMachine.MealyMachine;

public class NonDeterministicTestComparer {
	private MealyMachine m;
	private int mutType;
	private int numMuts;
	//private ArrayList<TestTester> ttList;
	private ArrayList<MealyMachine> mutList;
	private ArrayList<NonDeterministicTest> testList;
	private ArrayList<ArrayList<Integer>> compMatrix;
	
	public NonDeterministicTestComparer
		(MealyMachine m, int mutType, int numMuts, double prob){
		this.m=m;
		this.mutType=mutType;
		this.numMuts=numMuts;
		//ttList=new ArrayList<TestTester>();
		mutList = new ArrayList<MealyMachine>();
		testList = new ArrayList<NonDeterministicTest>();
		compMatrix = new ArrayList<ArrayList<Integer>>();
		createMutations(prob);
	}
	public void createMutations(double prob) {
		for(int i = 0; i < this.numMuts; i++) {
			this.mutList.add(m.generateMutant(this.mutType, prob));
		}
	}

	public void addTest(NonDeterministicTest t) {
		this.testList.add(t);
	}
	
	public void runAll(){
		for(int i = 0; i < testList.size(); i++) {
			ArrayList<Integer> tempComps = new ArrayList<Integer>();
			//testList.get(i).runTest();
			for(int j = 0; j < mutList.size(); j++) {
				tempComps.add(compare(testList.get(i), mutList.get(j)));
			}
			//Al salir del bucle tempComps es un arrayList con los valores de las comparaciones de testList(i)
			//runneado en la m�quina original vs en cada mutaci�n
			
			//Ahora a�adimos tempComps a compMatrix y pasamos al siguiente test
			compMatrix.add(tempComps);
		}
		
	}
	
	public Integer compare(NonDeterministicTest t, MealyMachine mutation){
		ArrayList<ArrayList<String>> outs = t.getOutputs();
		ArrayList<ArrayList<String>> outs2 = mutation.generateOutputs(t.getInputs());
		for(int i=0;i<outs2.size();i++) {
			if(!outs.contains(outs2.get(i)))return 1;
		}
		return 0;
	}
	
	
	
	public String getMatrix() {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < this.compMatrix.size(); i++) {
			sb.append(getRow(this.compMatrix.get(i)));
		}
		return sb.toString();
	}
	
	public void showMatrix() {
		for(int i = 0; i < this.compMatrix.size(); i++) {
			//System.out.println(this.compMatrix.get(i).size());
			showRow(this.compMatrix.get(i));
		}
	}
	
	public String getRow(ArrayList<Integer> list){
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < list.size(); i++) {
			sb.append(list.get(i).toString());
			sb.append(" ");
		}
		sb.append("\n");
		return sb.toString();
	}
	
	//Cada fila son los datos de las comparaciones de un test con todas las mutaciones
	public void showRow(ArrayList<Integer> list) {
		for(int i = 0; i < list.size(); i++) {
			System.out.print(list.get(i));
			System.out.print(' ');
		}
		System.out.print('\n');
	}
	
	public int getNumStates(){
		return this.m.getNumStates();
	}
	public int getAlphSize(){
		return this.m.getOutAlphSize();
	}
	public MealyMachine getMealy(){
		return this.m;
	}
	public int size(){
		return this.testList.size();
	}
}
