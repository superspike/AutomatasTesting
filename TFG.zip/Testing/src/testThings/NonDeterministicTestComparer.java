package testThings;

import java.util.ArrayList;

import mealyMachine.MealyMachine;

public class NonDeterministicTestComparer {
	private MealyMachine m;
	private int mutType;
	private int numMuts;
	//private ArrayList<TestTester> ttList;
	private ArrayList<MealyMachine> mutList;
	private ArrayList<NonDeterministicTest> testList;
	private ArrayList<ArrayList<Integer>> compMatrix;
}
