package testThings;

import java.util.ArrayList;
import java.util.LinkedList;

import mealyMachine.MealyMachine;

public class NonDeterministicTest {

	private ArrayList<String> inputs;
	private Tree trace;
	private MealyMachine m;
	
	public NonDeterministicTest(ArrayList<String> inps, MealyMachine mm) {
		inputs=inps;
		m=mm;
		trace=new Tree();
	}
	
	public void runTest() {
		trace=new Tree(0);
		LinkedList<Tree> cola=new LinkedList<Tree>();
		LinkedList<Tree> cola2=new LinkedList<Tree>();
		cola.push(trace);
		Tree caso;
		int i=0;
		while(!cola.isEmpty() && i<inputs.size()) {
			while(!cola.isEmpty()) {
				caso=cola.pop();
				caso.generateChilds(m, inputs.get(i));
				for(int j=0;j<caso.getNumChilds();j++) {
					cola2.push(caso.getChildTrees().get(j));
				}
			}
			cola=cola2;
			cola2=new LinkedList<Tree>();
			i++;
		}
	}
	
 
	
	public static void main(String args[]) {
		String m="digraph g {\n" + 
				"__start0 [label=\"\" shape=\"none\"];\n" + 
				"        __start0 -> s0;\n" + 
				"s0[shape=\"circle\" label=\"s0\"];\n" + 
				"s1[shape=\"circle\" label=\"s1\"];\n" + 
				"s2[shape=\"circle\" label=\"s2\"];\n" + 
				"s0 -> s1 [label=\"a / d\"];\n" + 
				"s0 -> s2 [label=\"a / a\"];\n" + 
				"s0 -> s0 [label=\"b / a\"];\n" + 
				"s0 -> s2 [label=\"b / a\"];\n" + 
				"s2 -> s2 [label=\"b / a\"];\n" + 
				"s2 -> s1 [label=\"b / d\"];\n" + 
				"s2 -> s0 [label=\"c / d\"];\n" + 
				"s1 -> s0 [label=\"c / d\"];\n" + 
				"}\n" 
				;
		try {
			MealyMachine mm=new MealyMachine(m,3,2);
			ArrayList<String> inps=new ArrayList<String>();
			inps.add("a");
			inps.add("c");
			inps.add("a");
			inps.add("c");
			inps.add("b");
			NonDeterministicTest test=new NonDeterministicTest(inps, mm);
			test.runTest();
			System.out.println(test.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String toString() {
		return trace.toString();
	}
	
}
