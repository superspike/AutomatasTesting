package testThings;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import javafx.util.Pair;
import mealyMachine.MealyMachine;

public class Tree {
	private ArrayList<Pair<Tree,String>> hijos;
	private Integer state;
	private String input;

	public Tree() {
	}
	public Tree(Integer a) {
		state=a;
	}
	
	public Tree(Integer a, String b) {
		state=a;
		input=b;
	}
	
	public Tree(Integer a, String b, ArrayList<Pair<Tree,String>> c) {
		hijos=c;
		state=a;
		input=b;
	}
	public void generateChilds(MealyMachine m, String i) {
		this.input=i;
		HashSet<Pair<Integer,String>> aux=m.setStatesI(state, input);
	    Iterator<Pair<Integer,String>> it = aux.iterator();
	    Tree caso;
	    hijos=new ArrayList<Pair<Tree,String>>();
		while(it.hasNext()) {
			Pair<Integer,String> act=it.next();
			caso=new Tree(act.getKey(),i);
			hijos.add(new Pair<Tree, String>((Tree) caso.clone(),act.getValue()));
		}
	}
	public Tree clone() {
		Tree ret=new Tree();
		ret.input=input;
		ret.state=this.state;
		return ret;
	}
	public ArrayList<Tree> getChildTrees(){
		ArrayList<Tree> ret=new ArrayList<Tree>();
		for(int i=0;i<this.hijos.size();i++) {
			ret.add(hijos.get(i).getKey());
		}
		return ret;
	}
	public int getNumChilds() {
		return hijos.size();
	}
	
	public ArrayList<ArrayList<String>> outputs() {
		ArrayList<String> outs=new ArrayList<String>();
		ArrayList<ArrayList<String>> ret=new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> aux=new ArrayList<ArrayList<String>>();
		if(hijos==null || hijos.size()<=0)return ret;
		for(int i=0;i<hijos.size();i++) {
			outs.add(hijos.get(i).getValue());
		}
		for(int i=0;i<hijos.size();i++) {
			aux=hijos.get(i).getKey().outputs();
			for(int j=0;j<aux.size();j++) {
				aux.get(j).add(0, hijos.get(i).getValue());
			}
			if(aux.size()<=0) {
				ArrayList<String> soloUno=new ArrayList<String>();
				soloUno.add(hijos.get(i).getValue());
				aux.add(soloUno);
			}
			ret.addAll(aux);
		}
		if(ret.size()==0) {
			for(int i=0;i<outs.size();i++) {
				ret.add(new ArrayList<String>());
				ret.get(i).add(outs.get(i));  
			}
		}
		return ret;
	}
	
	public String toString() {
		StringBuilder sb=new StringBuilder();
		
		ArrayList<ArrayList<String>> aux=this.outputs();
		
		for(int i=0;i<aux.size();i++) {
			sb.append(aux.get(i).toString());
			sb.append("\n");
		}
		
		return sb.toString();
	}
	
}
